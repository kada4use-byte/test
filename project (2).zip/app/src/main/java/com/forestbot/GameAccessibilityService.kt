package com.forestbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Does the actual tapping and swiping for the bot. */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GameAccessibilityService? = null
    }

    // The finger that is currently held on the screen (a continuing stroke), if any.
    private var stroke: GestureDescription.StrokeDescription? = null
    private var fingerX = 0f
    private var fingerY = 0f

    val fingerDown: Boolean get() = stroke != null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Keeps one finger down and slides it to (toX, y). Starts the touch at startX if none is down. */
    fun drag(toX: Float, y: Float, durationMs: Long, startX: Float): Boolean {
        try {
            val s = stroke
            val sx = if (s != null) fingerX else startX
            val sy = if (s != null) fingerY else y
            var ex = toX
            if (ex == sx && y == sy) ex += 0.5f
            val path = Path()
            path.moveTo(sx, sy)
            path.lineTo(ex, y)
            val desc = if (s == null) {
                GestureDescription.StrokeDescription(path, 0, durationMs, true)
            } else {
                s.continueStroke(path, 0, durationMs, true)
            }
            val ok = dispatchAndWait(desc, durationMs)
            if (ok) {
                stroke = desc
                fingerX = ex
                fingerY = y
            } else {
                stroke = null
            }
            return ok
        } catch (e: Exception) {
            stroke = null
            return false
        }
    }

    /** Lifts the finger. */
    fun release() {
        val s = stroke ?: return
        stroke = null
        try {
            val path = Path()
            path.moveTo(fingerX, fingerY)
            path.lineTo(fingerX + 0.5f, fingerY)
            dispatchAndWait(s.continueStroke(path, 0, 10, false), 10)
        } catch (e: Exception) {
        }
    }

    fun tap(x: Float, y: Float): Boolean {
        release()
        val p = Path()
        p.moveTo(x, y)
        return dispatchAndWait(GestureDescription.StrokeDescription(p, 0, 60), 60)
    }

    fun back() {
        release()
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun dispatchAndWait(stroke: GestureDescription.StrokeDescription, durationMs: Long): Boolean {
        val latch = CountDownLatch(1)
        var ok = false
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!accepted) return false
        latch.await(durationMs + 500, TimeUnit.MILLISECONDS)
        return ok
    }
}
