package com.forestbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val reqCapture = 1001
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(pad, pad * 2, pad, pad)

        val title = TextView(this)
        title.text = "Forest Bot"
        title.textSize = 28f
        root.addView(title)

        info = TextView(this)
        info.textSize = 16f
        info.setPadding(0, pad, 0, pad)
        root.addView(info)

        fun button(label: String, action: () -> Unit) {
            val b = Button(this)
            b.text = label
            b.setOnClickListener { action() }
            root.addView(b)
        }

        button("Step 1: Allow restricted settings (app info)") {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        }
        button("Step 2: Turn on Forest Bot in Accessibility") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("Step 3: Battery - set to Unrestricted") {
            try {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
        }
        button("Step 4: Allow 'Display over other apps' (shows the boxes)") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("START the bot and open the game") { startBot() }
        button("STOP the bot") { stopService(Intent(this, BotService::class.java)) }

        val scroll = ScrollView(this)
        scroll.addView(root)
        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val acc = if (GameAccessibilityService.instance != null) "ON" else "OFF"
        val run = if (BotService.running) "RUNNING" else "stopped"
        val boxes = if (Settings.canDrawOverlays(this)) "ON" else "OFF (do step 4)"
        info.text = "Accessibility: $acc\nBoxes overlay: $boxes\nBot: $run\n${BotService.status}"
    }

    private fun startBot() {
        if (GameAccessibilityService.instance == null) {
            Toast.makeText(this, "Turn on Forest Bot in Accessibility first (steps 1-2)", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            val game = packageManager.getLaunchIntentForPackage("com.RayGaming.ForestCleaner")
            if (game != null) {
                startActivity(game)
            } else {
                Toast.makeText(this, "Forest Cleaner is not installed - open it yourself", Toast.LENGTH_LONG).show()
            }
        }
    }
}
