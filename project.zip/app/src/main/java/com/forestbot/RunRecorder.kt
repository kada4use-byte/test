package com.forestbot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.provider.MediaStore
import android.view.Surface
import java.io.BufferedWriter
import java.io.File
import java.io.OutputStreamWriter
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Records one run of the game as a 60 fps MP4 (video of exactly what the screen showed, with the
 * bot's boxes) plus a CSV with what the bot saw and decided on every frame.
 *
 * Files go to  Movies/ForestBot  (video) and  Download/ForestBot  (csv), so they show up in the
 * Gallery / Files app. "Share last run" in the app sends both.
 *
 * All calls must come from ONE thread (the frame thread), except log() which has its own lock.
 */
class RunRecorder(private val ctx: Context, private val w: Int, private val h: Int) {

    private var codec: MediaCodec? = null
    private var muxer: MediaMuxer? = null
    private var surface: Surface? = null
    private var pfd: ParcelFileDescriptor? = null
    private var videoUri: Uri? = null
    private var csvUri: Uri? = null
    private var csv: BufferedWriter? = null
    private var drain: Thread? = null

    @Volatile
    private var track = -1
    @Volatile
    private var muxStarted = false

    private var bmp: Bitmap? = null
    private var tmp: ByteBuffer? = null
    var t0 = 0L
        private set
    var frames = 0
        private set

    val name: String = "run_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    /** Milliseconds since this recording started. */
    fun elapsed(): Long = SystemClock.elapsedRealtime() - t0

    fun start() {
        t0 = SystemClock.elapsedRealtime()

        // ---- encoder ----
        val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        fmt.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        fmt.setInteger(MediaFormat.KEY_BIT_RATE, 8_000_000)
        fmt.setInteger(MediaFormat.KEY_FRAME_RATE, 60)
        fmt.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        c.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        surface = c.createInputSurface()
        c.start()
        codec = c

        // ---- files ----
        val m: MediaMuxer
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.mp4")
            v.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ForestBot")
            v.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("cannot create video file")
            videoUri = u
            val p = ctx.contentResolver.openFileDescriptor(u, "rw")
                ?: throw IllegalStateException("cannot open video file")
            pfd = p
            m = MediaMuxer(p.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.csv")
            cv.put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ForestBot")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val cu = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            csvUri = cu
            if (cu != null) {
                val os = ctx.contentResolver.openOutputStream(cu)
                if (os != null) csv = BufferedWriter(OutputStreamWriter(os, "UTF-8"))
            }
        } else {
            val dir = File(ctx.getExternalFilesDir(null), "ForestBot")
            dir.mkdirs()
            val vf = File(dir, "$name.mp4")
            m = MediaMuxer(vf.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            videoUri = Uri.fromFile(vf)
            val cf = File(dir, "$name.csv")
            csv = BufferedWriter(OutputStreamWriter(cf.outputStream(), "UTF-8"))
            csvUri = Uri.fromFile(cf)
        }
        muxer = m
        csv?.write("t_ms,screen,bin_x,bin_y,target,objects(kind:cx:cy:w:h;...)\n")

        // ---- thread that moves finished video from the encoder into the file ----
        drain = Thread {
            val info = MediaCodec.BufferInfo()
            try {
                while (true) {
                    val idx = c.dequeueOutputBuffer(info, 10_000)
                    if (idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        track = m.addTrack(c.outputFormat)
                        m.start()
                        muxStarted = true
                    } else if (idx >= 0) {
                        val buf = c.getOutputBuffer(idx)
                        if (buf != null && info.size > 0 && muxStarted &&
                            (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) == 0
                        ) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            m.writeSampleData(track, buf, info)
                        }
                        c.releaseOutputBuffer(idx, false)
                        if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) break
                    }
                }
            } catch (e: Exception) {
                AppLog.add("recorder drain stopped: $e")
            }
        }.also { it.start() }
        AppLog.add("recording $name (60 fps, ${w}x$h)")
    }

    /** Adds one captured frame (RGBA) to the video. */
    fun push(img: Image) {
        val s = surface ?: return
        val pl = img.planes[0]
        val rs = pl.rowStride
        var b = bmp
        if (b == null) {
            b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp = b
        }
        var t = tmp
        if (t == null) {
            t = ByteBuffer.allocateDirect(w * h * 4)
            tmp = t
        }
        t.clear()
        val d = pl.buffer.duplicate()
        for (y in 0 until h) {
            val end = minOf(d.capacity(), y * rs + w * 4)
            d.limit(end)
            d.position(minOf(y * rs, end))
            t.put(d)
        }
        t.rewind()
        b!!.copyPixelsFromBuffer(t)
        val canvas = s.lockCanvas(null)
        try {
            canvas.drawBitmap(b, 0f, 0f, null)
        } finally {
            s.unlockCanvasAndPost(canvas)
        }
        frames++
    }

    /** One line of the CSV (thread safe). */
    fun log(line: String) {
        synchronized(this) {
            val out = csv ?: return
            try {
                out.write(line)
                out.write("\n")
            } catch (_: Exception) {
            }
        }
    }

    /** Finishes the files. Returns after the video is closed. */
    fun stop() {
        try { codec?.signalEndOfInputStream() } catch (_: Exception) {}
        try { drain?.join(3000) } catch (_: Exception) {}
        try { codec?.stop() } catch (_: Exception) {}
        try { codec?.release() } catch (_: Exception) {}
        try { surface?.release() } catch (_: Exception) {}
        try { if (muxStarted) muxer?.stop() } catch (e: Exception) { AppLog.add("muxer stop: $e") }
        try { muxer?.release() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
        synchronized(this) {
            try { csv?.flush(); csv?.close() } catch (_: Exception) {}
            csv = null
        }
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            try { videoUri?.let { ctx.contentResolver.update(it, done, null, null) } } catch (_: Exception) {}
            try { csvUri?.let { ctx.contentResolver.update(it, done, null, null) } } catch (_: Exception) {}
        }
        // remember the last run so the app can offer to share it
        try {
            ctx.getSharedPreferences("rec", Context.MODE_PRIVATE).edit()
                .putString("video", videoUri?.toString())
                .putString("csv", csvUri?.toString())
                .putString("name", name)
                .putInt("frames", frames)
                .apply()
        } catch (_: Exception) {
        }
        AppLog.add("saved $name  ($frames frames)")
    }
}
