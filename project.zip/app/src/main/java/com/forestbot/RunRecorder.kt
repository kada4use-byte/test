package com.forestbot

import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Saves one run of the game as a ZIP of JPEG frames (every screen frame, up to 60 per second),
 * plus data.csv (what the bot saw and decided) and frames.csv (the time of each frame).
 *
 * Runs pile up in the app's own folder (up to MAX_RUNS, oldest are deleted). The app's
 * "Export" buttons pack them into ONE zip to send.
 *
 * push() / start() / stop() must be called from ONE thread (the frame thread). log() is thread safe.
 */
class RunRecorder(private val ctx: Context, private val w: Int, private val h: Int) {

    companion object {
        const val MAX_RUNS = 100

        fun runsDir(ctx: Context): File {
            val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
            return File(base, "runs")
        }

        /** Runs waiting to be sent (.zip). */
        fun runFiles(ctx: Context): List<File> =
            (runsDir(ctx).listFiles { f -> f.name.endsWith(".zip") }?.toList() ?: emptyList()).sortedBy { it.name }

        /** Runs already exported in a part (.sent): kept until you delete them, but not exported again. */
        fun sentFiles(ctx: Context): List<File> =
            (runsDir(ctx).listFiles { f -> f.name.endsWith(".sent") }?.toList() ?: emptyList()).sortedBy { it.name }

        /** Saved frame rate (frames per second kept per run). */
        fun fps(ctx: Context): Int = ctx.getSharedPreferences("rec", Context.MODE_PRIVATE).getInt("fps", 20)

        fun nextFps(ctx: Context): Int {
            val n = when (fps(ctx)) { 60 -> 30; 30 -> 20; 20 -> 10; else -> 60 }
            ctx.getSharedPreferences("rec", Context.MODE_PRIVATE).edit().putInt("fps", n).apply()
            return n
        }

        /** Deletes the oldest runs beyond MAX_RUNS (already-sent ones first). */
        fun prune(ctx: Context) {
            val all = (runFiles(ctx) + sentFiles(ctx)).sortedBy { it.name }
            for (i in 0 until all.size - MAX_RUNS) try { all[i].delete() } catch (_: Exception) {}
        }
    }

    private class Frame(val bmp: Bitmap?, val idx: Int, val t: Long)

    private var out: OutputStream? = null
    private var zip: ZipOutputStream? = null
    private var file: File? = null
    private var writer: Thread? = null

    private val free = ArrayBlockingQueue<Bitmap>(8)
    private val queue = ArrayBlockingQueue<Frame>(16)
    private val frameTimes = StringBuilder("frame,t_ms\n")
    private val data = StringBuilder("t_ms,screen,bin_x,bin_y,target,objects(kind:cx:cy:w:h;...)\n")
    private var tmp: ByteBuffer? = null
    private val ctl = StringBuilder("t_ms,fx,des,i_term,finger_down,drag_ok,drag_ms,bin_x,target,event\n")

    var t0 = 0L
        private set

    private var minGapMs = 16L
    private var lastSavedT = -1000L

    @Volatile
    var frames = 0
        private set

    @Volatile
    var dropped = 0
        private set

    val name: String = "run_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun start() {
        t0 = SystemClock.elapsedRealtime()
        minGapMs = (1000L / fps(ctx).coerceIn(5, 60)) - 4L

        val dir = runsDir(ctx)
        dir.mkdirs()
        if (dir.usableSpace < 500L * 1024 * 1024) throw IllegalStateException("less than 500 MB free - not recording")
        val f = File(dir, "$name.zip")
        file = f
        val os: OutputStream = f.outputStream()
        out = os
        val z = ZipOutputStream(os.buffered(256 * 1024))
        z.setLevel(Deflater.NO_COMPRESSION)   // JPEGs are already compressed; this keeps it fast
        zip = z

        for (i in 0 until 8) free.add(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))

        writer = Thread {
            val jpg = ByteArrayOutputStream(64 * 1024)
            try {
                while (true) {
                    val f = queue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    val b = f.bmp ?: break          // empty frame = "finished"
                    jpg.reset()
                    b.compress(Bitmap.CompressFormat.JPEG, 50, jpg)
                    z.putNextEntry(ZipEntry("f_%05d.jpg".format(f.idx)))
                    jpg.writeTo(z)
                    z.closeEntry()
                    free.offer(b)
                }
            } catch (e: Exception) {
                AppLog.add("frame writer stopped: $e")
            }
        }.also { it.start() }
        AppLog.add("recording frames to $name.zip (${w}x$h, ${fps(ctx)} fps), ${runFiles(ctx).size} runs waiting")
    }

    /** Adds one captured frame (RGBA). If the writer is too slow the frame is skipped and counted. */
    fun push(img: Image) {
        val nowT = SystemClock.elapsedRealtime() - t0
        if (nowT - lastSavedT < minGapMs) return   // frame-rate limit (keeps the files small)
        lastSavedT = nowT
        val b = free.poll()
        if (b == null) {
            dropped++
            return
        }
        val pl = img.planes[0]
        val rs = pl.rowStride
        val t: ByteBuffer = tmp ?: ByteBuffer.allocateDirect(w * h * 4).also { tmp = it }
        t.clear()
        val d = pl.buffer.duplicate()
        for (y in 0 until h) {
            val end = minOf(d.capacity(), y * rs + w * 4)
            d.limit(end)
            d.position(minOf(y * rs, end))
            t.put(d)
        }
        t.rewind()
        b.copyPixelsFromBuffer(t)
        val now = SystemClock.elapsedRealtime() - t0
        frames++
        frameTimes.append(frames).append(',').append(now).append('\n')
        if (!queue.offer(Frame(b, frames, now))) {
            free.offer(b)
            dropped++
        }
    }

    /** One line of data.csv (thread safe). */
    fun log(line: String) {
        synchronized(data) {
            data.append(line).append('\n')
        }
    }

    /** One line of ctl.csv: what the finger controller did (thread safe). */
    fun logCtl(line: String) {
        synchronized(ctl) {
            if (ctl.length < 4_000_000) ctl.append(line).append('\n')
        }
    }

    /** Finishes the ZIP. Returns once the file is closed. */
    fun stop() {
        try { queue.offer(Frame(null, 0, 0), 2, TimeUnit.SECONDS) } catch (_: Exception) {}
        try { writer?.join(15000) } catch (_: Exception) {}
        val z = zip
        if (z != null) {
            try {
                z.putNextEntry(ZipEntry("frames.csv"))
                z.write(frameTimes.toString().toByteArray())
                z.closeEntry()
                synchronized(data) {
                    z.putNextEntry(ZipEntry("data.csv"))
                    z.write(data.toString().toByteArray())
                    z.closeEntry()
                }
                synchronized(ctl) {
                    z.putNextEntry(ZipEntry("ctl.csv"))
                    z.write(ctl.toString().toByteArray())
                    z.closeEntry()
                }
                z.putNextEntry(ZipEntry("info.txt"))
                z.write("frames=$frames dropped=$dropped size=${w}x$h fps=${fps(ctx)}\n".toByteArray())
                z.closeEntry()
            } catch (e: Exception) {
                AppLog.add("zip finish: $e")
            }
            try { z.close() } catch (_: Exception) {}
        }
        try { out?.close() } catch (_: Exception) {}
        // a "run" with only a handful of frames is a false start - throw it away
        if (frames < 20) {
            try { file?.delete() } catch (_: Exception) {}
        } else {
            prune(ctx)
        }
        try {
            ctx.getSharedPreferences("rec", Context.MODE_PRIVATE).edit()
                .putString("name", name)
                .putInt("frames", frames)
                .apply()
        } catch (_: Exception) {
        }
        AppLog.add("saved $name.zip  ($frames frames, $dropped skipped)")
    }
}
