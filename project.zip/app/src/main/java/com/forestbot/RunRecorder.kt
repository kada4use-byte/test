package com.forestbot

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.media.Image
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import android.provider.MediaStore
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.OutputStream
import java.nio.ByteBuffer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.TimeUnit
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Saves one run of the game as a ZIP of JPEG frames (every screen frame, up to 60 per second),
 * plus data.csv (what the bot saw and decided) and frames.csv (the time of each frame).
 *
 * The ZIP goes to  Download/ForestBot/run_<date>_<time>.zip  so it shows up in the Files app.
 * "Share last run" in the app sends it.
 *
 * push() / start() / stop() must be called from ONE thread (the frame thread). log() is thread safe.
 */
class RunRecorder(private val ctx: Context, private val w: Int, private val h: Int) {

    private class Frame(val bmp: Bitmap?, val idx: Int, val t: Long)

    private var out: OutputStream? = null
    private var zip: ZipOutputStream? = null
    private var uri: Uri? = null
    private var writer: Thread? = null

    private val free = ArrayBlockingQueue<Bitmap>(8)
    private val queue = ArrayBlockingQueue<Frame>(16)
    private val frameTimes = StringBuilder("frame,t_ms\n")
    private val data = StringBuilder("t_ms,screen,bin_x,bin_y,target,objects(kind:cx:cy:w:h;...)\n")
    private var tmp: ByteBuffer? = null

    var t0 = 0L
        private set

    @Volatile
    var frames = 0
        private set

    @Volatile
    var dropped = 0
        private set

    val name: String = "run_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    fun start() {
        t0 = SystemClock.elapsedRealtime()

        val os: OutputStream
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, "$name.zip")
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ForestBot")
            v.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val u = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("cannot create file")
            uri = u
            os = ctx.contentResolver.openOutputStream(u)
                ?: throw IllegalStateException("cannot open file")
        } else {
            val dir = File(ctx.getExternalFilesDir(null), "ForestBot")
            dir.mkdirs()
            val f = File(dir, "$name.zip")
            uri = Uri.fromFile(f)
            os = f.outputStream()
        }
        out = os
        val z = ZipOutputStream(os.buffered(256 * 1024))
        z.setLevel(Deflater.NO_COMPRESSION)   // JPEGs are already compressed; this keeps it fast
        zip = z

        for (i in 0 until 8) free.add(Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888))

        writer = Thread {
            val jpg = ByteArrayOutputStream(64 * 1024)
            try {
                while (true) {
                    val f = queue.poll(500, TimeUnit.MILLISECONDS) ?: continue
                    val b = f.bmp ?: break          // empty frame = "finished"
                    jpg.reset()
                    b.compress(Bitmap.CompressFormat.JPEG, 80, jpg)
                    z.putNextEntry(ZipEntry("f_%05d.jpg".format(f.idx)))
                    jpg.writeTo(z)
                    z.closeEntry()
                    free.offer(b)
                }
            } catch (e: Exception) {
                AppLog.add("frame writer stopped: $e")
            }
        }.also { it.start() }
        AppLog.add("recording frames to $name.zip (${w}x$h)")
    }

    /** Adds one captured frame (RGBA). If the writer is too slow the frame is skipped and counted. */
    fun push(img: Image) {
        val b = free.poll()
        if (b == null) {
            dropped++
            return
        }
        val pl = img.planes[0]
        val rs = pl.rowStride
        val t: ByteBuffer = tmp ?: ByteBuffer.allocateDirect(w * h * 4).also { tmp = it }
        t.clear()
        val d = pl.buffer.duplicate()
        for (y in 0 until h) {
            val end = minOf(d.capacity(), y * rs + w * 4)
            d.limit(end)
            d.position(minOf(y * rs, end))
            t.put(d)
        }
        t.rewind()
        b.copyPixelsFromBuffer(t)
        val now = SystemClock.elapsedRealtime() - t0
        frames++
        frameTimes.append(frames).append(',').append(now).append('\n')
        if (!queue.offer(Frame(b, frames, now))) {
            free.offer(b)
            dropped++
        }
    }

    /** One line of data.csv (thread safe). */
    fun log(line: String) {
        synchronized(data) {
            data.append(line).append('\n')
        }
    }

    /** Finishes the ZIP. Returns once the file is closed. */
    fun stop() {
        try { queue.offer(Frame(null, 0, 0), 2, TimeUnit.SECONDS) } catch (_: Exception) {}
        try { writer?.join(15000) } catch (_: Exception) {}
        val z = zip
        if (z != null) {
            try {
                z.putNextEntry(ZipEntry("frames.csv"))
                z.write(frameTimes.toString().toByteArray())
                z.closeEntry()
                synchronized(data) {
                    z.putNextEntry(ZipEntry("data.csv"))
                    z.write(data.toString().toByteArray())
                    z.closeEntry()
                }
                z.putNextEntry(ZipEntry("info.txt"))
                z.write("frames=$frames dropped=$dropped size=${w}x$h\n".toByteArray())
                z.closeEntry()
            } catch (e: Exception) {
                AppLog.add("zip finish: $e")
            }
            try { z.close() } catch (_: Exception) {}
        }
        try { out?.close() } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 29) {
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            try { uri?.let { ctx.contentResolver.update(it, done, null, null) } } catch (_: Exception) {}
        }
        try {
            ctx.getSharedPreferences("rec", Context.MODE_PRIVATE).edit()
                .putString("zip", uri?.toString())
                .putString("name", name)
                .putInt("frames", frames)
                .apply()
        } catch (_: Exception) {
        }
        AppLog.add("saved $name.zip  ($frames frames, $dropped skipped)")
    }
}
