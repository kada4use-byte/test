package com.forestbot

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Draws hitbox-style boxes on top of the game (like Minecraft's F3+B).
 * Only magenta/violet colours are used, because the bot's vision ignores exactly those colours.
 */
class BoxOverlay(context: Context) : View(context) {

    class Box(val l: Float, val t: Float, val r: Float, val b: Float, val kind: Int, val label: String)

    class Data(
        val boxes: List<Box>,
        val targetX: Float,   // screen px, -1 for none
        val lineTop: Float,
        val lineBottom: Float,
        val title: String
    )

    companion object {
        const val K_HAZARD = 0
        const val K_LITTER = 1
        const val K_COIN = 2
        const val K_BIN = 3
    }

    @Volatile
    private var data: Data? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val loc = IntArray(2)

    fun update(d: Data?) {
        data = d
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val d = data ?: return
        getLocationOnScreen(loc)
        canvas.translate(-loc[0].toFloat(), -loc[1].toFloat())
        paint.style = Paint.Style.STROKE
        paint.textSize = 34f

        for (b in d.boxes) {
            when (b.kind) {
                K_HAZARD -> { paint.color = Color.rgb(255, 0, 255); paint.strokeWidth = 7f }
                K_LITTER -> { paint.color = Color.rgb(170, 70, 255); paint.strokeWidth = 5f }
                K_COIN -> { paint.color = Color.rgb(200, 110, 255); paint.strokeWidth = 5f }
                else -> { paint.color = Color.rgb(255, 60, 200); paint.strokeWidth = 5f }
            }
            canvas.drawRect(b.l, b.t, b.r, b.b, paint)
            paint.style = Paint.Style.FILL
            canvas.drawText(b.label, b.l, b.t - 8f, paint)
            paint.style = Paint.Style.STROKE
        }

        if (d.targetX >= 0f) {
            paint.color = Color.rgb(255, 0, 255)
            paint.strokeWidth = 4f
            canvas.drawLine(d.targetX, d.lineTop, d.targetX, d.lineBottom, paint)
            paint.style = Paint.Style.FILL
            canvas.drawText("GO", d.targetX + 10f, d.lineTop + 34f, paint)
            paint.style = Paint.Style.STROKE
        }

        if (d.title.isNotEmpty()) {
            paint.style = Paint.Style.FILL
            paint.color = Color.rgb(255, 0, 255)
            canvas.drawText(d.title, 24f, 120f, paint)
        }
    }
}
