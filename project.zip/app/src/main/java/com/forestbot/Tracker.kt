package com.forestbot

import kotlin.math.abs

/** Follows objects from frame to frame so boxes are smooth and have a speed. Vision thread only. */
object Tracker {
    private class T(
        var kind: Int, var cx: Float, var cy: Float, var w: Float, var h: Float,
        var vx: Float, var hits: Int, var miss: Int, var hz: Float, var lk: Int,
        var cutHz: Int = 0,
        var sure: Int = 0   // frames in which this was a hazard AND fully visible; 2+ = hazard for good
    )

    private val tracks = ArrayList<T>()
    private const val LAT = 0.12f  // seconds between the screen and what we draw / plan on (measured boxes trailing objects by 0.07-0.2 s)

    fun reset() {
        tracks.clear()
    }

    fun update(dets: List<Vision.Obj>, dt: Float): List<Vision.Obj> {
        val d = dt.coerceIn(0.01f, 0.3f)
        for (t in tracks) {
            t.cy += 0.70f * d
            t.cx += t.vx * d
        }
        val used = BooleanArray(dets.size)
        for (t in tracks) {
            var bi = -1
            var bd = 1e9f
            for (i in dets.indices) {
                if (used[i]) continue
                val o = dets[i]
                val dx = abs(o.cx - t.cx)
                val dy = abs(o.cy - t.cy)
                if (dx < 0.09f && dy < 0.09f && dx + dy < bd) {
                    bd = dx + dy
                    bi = i
                }
            }
            if (bi < 0) {
                t.miss++
                continue
            }
            used[bi] = true
            val o = dets[bi]
            val nvx = ((o.cx - t.cx) / d)
            t.vx = (0.88f * t.vx + 0.12f * nvx).coerceIn(-0.6f, 0.6f)
            if (t.hits < 3) t.vx = 0f
            t.cx = 0.5f * t.cx + 0.5f * o.cx
            t.cy = 0.4f * t.cy + 0.6f * o.cy
            t.w = 0.6f * t.w + 0.4f * o.w
            t.h = 0.6f * t.h + 0.4f * o.h
            t.hz = 0.6f * t.hz + 0.4f * (if (o.kind == Vision.HAZARD) 1f else 0f)
            if (o.kind != Vision.HAZARD) t.lk = o.kind
            if (o.kind == Vision.HAZARD && !o.cut) t.sure++
            if (o.kind == Vision.HAZARD && o.cut) t.cutHz++
            // once an animal / stump has clearly been seen it stays one (it used to flip back to
            // "loot" for a few frames and the bot drove into it)
            t.kind = if (t.sure >= 2 || t.cutHz >= 4 || t.hz > 0.45f) Vision.HAZARD else t.lk
            t.hits++
            t.miss = 0
        }
        for (i in dets.indices) {
            if (!used[i]) {
                val o = dets[i]
                tracks.add(T(o.kind, o.cx, o.cy, o.w, o.h, 0f, 1, 0, if (o.kind == Vision.HAZARD) 1f else 0f, if (o.kind == Vision.HAZARD) Vision.LITTER else o.kind, 0, if (o.kind == Vision.HAZARD && !o.cut) 1 else 0))
            }
        }
        tracks.removeAll { it.miss > 3 || it.cy > 1.0f || it.cy < -0.2f }
        val out = ArrayList<Vision.Obj>()
        for (t in tracks) {
            val ok = if (t.kind == Vision.HAZARD) (t.hits >= 1 && t.miss <= 2) else (t.hits >= 2 && t.miss <= 1)
            if (ok) {
                val v = if (t.hits >= 7 && abs(t.vx) > 0.07f) t.vx else 0f
                out.add(Vision.Obj(t.kind, t.cx + v * LAT, t.cy + 0.70f * LAT, t.w, t.h, v))
            }
        }
        return out
    }
}
