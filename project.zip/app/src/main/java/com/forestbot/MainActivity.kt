package com.forestbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Game(val name: String, val pkg: String, val blurb: String)

    private val games = listOf(
        Game("Forest Cleaner", "com.RayGaming.ForestCleaner", "Collects litter and coins, dodges obstacles")
    )

    private val BG = Color.rgb(15, 17, 21)
    private val CARD = Color.rgb(27, 31, 39)
    private val TEXT = Color.WHITE
    private val SUB = Color.rgb(150, 158, 172)
    private val ACCENT = Color.rgb(34, 211, 238)
    private val GOOD = Color.rgb(163, 230, 53)
    private val WARN = Color.rgb(251, 146, 60)

    private val reqCapture = 1001
    private var pendingGame: Game? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private var showSetup = false
    private var lastKey = ""
    private lateinit var logView: TextView
    private lateinit var statusView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), dp(40), dp(18), dp(28))
        scroll.addView(content)
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onResume() {
        super.onResume()
        lastKey = ""
        ticker.run()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun accOn() = GameAccessibilityService.instance != null
    private fun overlayOn() = Settings.canDrawOverlays(this)
    private fun ready() = accOn() && overlayOn()

    private fun refresh() {
        val key = "${accOn()}|${overlayOn()}|${BotService.running}|$showSetup|${RunRecorder.runFiles(this).size}|${RunRecorder.sentFiles(this).size}|${RunRecorder.fps(this)}|$exporting"
        if (key != lastKey) {
            lastKey = key
            build()
        }
        statusView.text = if (BotService.running) BotService.status else ""
        logView.text = AppLog.tail(this, 12).ifEmpty { "(nothing yet)" }
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(CARD, 18)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    private fun pill(label: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.textSize = 14f
        b.background = round(color, 20)
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(16), dp(8), dp(16), dp(8))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun setupRow(parent: LinearLayout, ok: Boolean, title: String, hint: String, action: String, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val dot = View(this)
        dot.background = round(if (ok) GOOD else WARN, 8)
        row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        col.addView(text(title, 15f, TEXT, true))
        col.addView(text(hint, 12f, SUB))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(pill(if (ok) "Done" else action, if (ok) Color.rgb(90, 98, 112) else ACCENT, onClick))
        parent.addView(row)
    }

    private fun build() {
        content.removeAllViews()

        // header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_fg)
        logo.background = round(Color.rgb(15, 27, 45), 14)
        head.addView(logo, LinearLayout.LayoutParams(dp(52), dp(52)))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        ht.setPadding(dp(14), 0, 0, 0)
        ht.addView(text("OxyDoxy", 28f, TEXT, true))
        ht.addView(text("Your phone plays games for you", 13f, SUB))
        head.addView(ht)
        val hl = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        hl.setMargins(0, 0, 0, dp(20))
        content.addView(head, hl)

        // running banner
        if (BotService.running) {
            val c = card()
            c.addView(text("Bot is running", 16f, GOOD, true))
            statusView = text("", 12f, SUB)
            c.addView(statusView)
            val b = pill("Stop", Color.rgb(248, 113, 113)) {
                stopService(Intent(this, BotService::class.java))
            }
            val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(10)
            c.addView(b, lp)
            content.addView(c)
        } else {
            statusView = text("", 12f, SUB)
        }

        // saved runs: every frame of every run, kept even if you stop and restart the bot
        val runs = RunRecorder.runFiles(this)
        val sent = RunRecorder.sentFiles(this)
        if (runs.isNotEmpty() || sent.isNotEmpty() || exporting) {
            val rc = card()
            val waitMb = runs.sumOf { it.length() } / (1024.0 * 1024.0)
            val parts = Math.ceil(waitMb / PART_MB).toInt()
            rc.addView(text("Saved runs: ${runs.size} waiting (${"%.1f".format(waitMb)} MB), ${sent.size} already sent", 15f, TEXT, true))
            rc.addView(text(
                if (exporting) "Packing... this can take a minute"
                else "Upload limit is 30 MB, so export goes in parts of at most $PART_MB MB. Waiting runs = about $parts part(s).", 12f, SUB))
            if (!exporting) {
                fun lp(top: Int): LinearLayout.LayoutParams {
                    val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                    l.topMargin = dp(top)
                    return l
                }
                rc.addView(pill("Export next part (max $PART_MB MB)", ACCENT) { exportPart() }, lp(10))
                rc.addView(pill("Export data only (tiny, all runs)", Color.rgb(90, 98, 112)) { exportData() }, lp(8))
                rc.addView(pill("Frames saved per second: ${RunRecorder.fps(this)}  (tap to change)", Color.rgb(90, 98, 112)) {
                    RunRecorder.nextFps(this)
                    lastKey = ""
                }, lp(8))
                rc.addView(text("Lower = smaller files. 60 = every frame (about 6 MB per run), 20 = about 2 MB per run.", 11f, Color.rgb(100, 108, 122)), lp(4))
                if (sent.isNotEmpty()) rc.addView(pill("Delete the ${sent.size} sent runs", Color.rgb(248, 113, 113)) {
                    for (f in RunRecorder.sentFiles(this)) try { f.delete() } catch (_: Exception) {}
                    lastKey = ""
                }, lp(8))
                rc.addView(pill("Delete everything saved", Color.rgb(248, 113, 113)) {
                    for (f in RunRecorder.runFiles(this) + RunRecorder.sentFiles(this)) try { f.delete() } catch (_: Exception) {}
                    lastKey = ""
                }, lp(8))
            }
            content.addView(rc)
        }

        // setup
        val ok = ready()
        val sc = card()
        if (ok && !showSetup) {
            val r = LinearLayout(this)
            r.orientation = LinearLayout.HORIZONTAL
            r.gravity = Gravity.CENTER_VERTICAL
            val t = text("Setup complete", 15f, GOOD, true)
            r.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            r.addView(pill("Show", Color.rgb(90, 98, 112)) { showSetup = true })
            sc.addView(r)
        } else {
            sc.addView(text("Setup", 18f, TEXT, true))
            sc.addView(text("Do these once. Each one opens the right Settings page.", 12f, SUB))
            setupRow(sc, false, "1. Allow restricted settings", "Do this first if Accessibility is greyed out", "Open") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            setupRow(sc, accOn(), "2. Accessibility", "Turn on OxyDoxy so it can tap for you", "Open") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            setupRow(sc, overlayOn(), "3. Display over other apps", "Shows boxes and the Pause / Stop buttons", "Allow") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            setupRow(sc, false, "4. Battery: Unrestricted", "Stops the phone from killing the bot", "Open") {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }
            }
            if (ok) {
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.topMargin = dp(8)
                sc.addView(pill("Hide setup", Color.rgb(90, 98, 112)) { showSetup = false }, lp)
            }
        }
        content.addView(sc)

        // games
        val gl = text("GAMES", 12f, SUB, true)
        gl.setPadding(dp(4), dp(8), 0, dp(8))
        content.addView(gl)
        for (g in games) content.addView(gameCard(g))
        val soon = card()
        soon.addView(text("More games coming soon", 15f, SUB, true))
        soon.addView(text("Tell me which game you want next", 12f, Color.rgb(100, 108, 122)))
        content.addView(soon)

        // log
        val lg = card()
        lg.addView(text("Activity log", 13f, SUB, true))
        logView = text("", 11f, Color.rgb(170, 178, 192))
        logView.typeface = Typeface.MONOSPACE
        lg.addView(logView)
        content.addView(lg)
    }

    @Volatile
    private var exporting = false

    private val PART_MB = 25

    /** Creates a zip in Download/ForestBot and gives [fill] the stream to write into. Returns its Uri. */
    private fun newExportFile(name: String, fill: (java.util.zip.ZipOutputStream) -> Unit): Uri {
        val uri: Uri
        val os: java.io.OutputStream
        if (Build.VERSION.SDK_INT >= 29) {
            val v = android.content.ContentValues()
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "$name.zip")
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/zip")
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/ForestBot")
            v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
            val u = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("cannot create the export file")
            uri = u
            os = contentResolver.openOutputStream(u) ?: throw IllegalStateException("cannot open the export file")
        } else {
            val dir = java.io.File(getExternalFilesDir(null), "export")
            dir.mkdirs()
            val f = java.io.File(dir, "$name.zip")
            uri = Uri.fromFile(f)
            os = f.outputStream()
        }
        val z = java.util.zip.ZipOutputStream(os.buffered(1 shl 20))
        z.setLevel(java.util.zip.Deflater.NO_COMPRESSION)
        fill(z)
        z.close()
        if (Build.VERSION.SDK_INT >= 29) {
            val done = android.content.ContentValues()
            done.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, done, null, null)
        }
        return uri
    }

    private fun stamp() = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    private fun finishExport(uri: Uri?, err: String, doneMsg: String) {
        exporting = false
        handler.post {
            lastKey = ""
            if (err.isNotEmpty() || uri == null) {
                Toast.makeText(this, "Export failed: $err", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, doneMsg, Toast.LENGTH_LONG).show()
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "application/zip"
                    i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Send this part"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Saved in Download/ForestBot", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Packs the oldest waiting runs into ONE zip of at most PART_MB, marks them as sent, and offers to share it. */
    private fun exportPart() {
        if (exporting) return
        exporting = true
        lastKey = ""
        Thread {
            var uri: Uri? = null
            var err = ""
            var msg = ""
            try {
                val limit = PART_MB * 1024L * 1024L
                val chosen = ArrayList<java.io.File>()
                var total = 0L
                for (f in RunRecorder.runFiles(this)) {
                    if (chosen.isNotEmpty() && total + f.length() > limit) break
                    chosen.add(f)
                    total += f.length()
                }
                if (chosen.isEmpty()) throw IllegalStateException("no runs waiting")
                val leftBefore = RunRecorder.runFiles(this).size - chosen.size
                uri = newExportFile("forestbot_part_" + stamp()) { z ->
                    for (f in chosen) {
                        z.putNextEntry(java.util.zip.ZipEntry(f.name))
                        f.inputStream().use { it.copyTo(z, 1 shl 16) }
                        z.closeEntry()
                    }
                }
                for (f in chosen) {
                    try { f.renameTo(java.io.File(f.parentFile, f.name.removeSuffix(".zip") + ".sent")) } catch (_: Exception) {}
                }
                msg = "${chosen.size} runs, ${total / (1024 * 1024)} MB. $leftBefore runs still waiting."
                AppLog.add("exported part: $msg")
            } catch (e: Throwable) {
                err = e.toString()
                AppLog.add("export failed: $e")
            }
            finishExport(uri, err, msg)
        }.start()
    }

    /** One small zip with only data.csv / frames.csv / info.txt of EVERY saved run (no images). */
    private fun exportData() {
        if (exporting) return
        exporting = true
        lastKey = ""
        Thread {
            var uri: Uri? = null
            var err = ""
            var msg = ""
            try {
                val files = (RunRecorder.runFiles(this) + RunRecorder.sentFiles(this)).sortedBy { it.name }
                if (files.isEmpty()) throw IllegalStateException("no runs saved yet")
                var n = 0
                uri = newExportFile("forestbot_data_" + stamp()) { z ->
                    z.setLevel(java.util.zip.Deflater.BEST_COMPRESSION)
                    for (f in files) {
                        try {
                            java.util.zip.ZipFile(f).use { zf ->
                                val base = f.name.removeSuffix(".zip").removeSuffix(".sent")
                                for (en in listOf("data.csv", "frames.csv", "info.txt")) {
                                    val e = zf.getEntry(en) ?: continue
                                    z.putNextEntry(java.util.zip.ZipEntry(base + "/" + en))
                                    zf.getInputStream(e).use { it.copyTo(z, 1 shl 15) }
                                    z.closeEntry()
                                }
                                n++
                            }
                        } catch (_: Exception) {
                            // a run that was cut off (app killed while recording) has no index: skip it
                        }
                    }
                }
                msg = "data of $n runs"
                AppLog.add("exported data only: $msg")
            } catch (e: Throwable) {
                err = e.toString()
                AppLog.add("export failed: $e")
            }
            finishExport(uri, err, msg)
        }.start()
    }

    private fun gameCard(g: Game): LinearLayout {
        val c = card()
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        val icon = ImageView(this)
        var installed = true
        try {
            icon.setImageDrawable(packageManager.getApplicationIcon(g.pkg))
        } catch (e: Exception) {
            installed = false
            icon.setImageResource(R.drawable.ic_fg)
            icon.background = round(Color.rgb(15, 27, 45), 14)
        }
        row.addView(icon, LinearLayout.LayoutParams(dp(60), dp(60)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(14), 0, dp(8), 0)
        col.addView(text(g.name, 17f, TEXT, true))
        col.addView(text(if (installed) g.blurb else "Not installed", 12f, SUB))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(pill(if (BotService.running) "Running" else "Start", if (BotService.running) Color.rgb(90, 98, 112) else GOOD) { startGame(g) })
        c.addView(row)
        c.setOnClickListener { startGame(g) }
        return c
    }

    private fun startGame(g: Game) {
        if (BotService.running) {
            Toast.makeText(this, "Already running. Press Stop first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!ready()) {
            showSetup = true
            lastKey = ""
            scroll.smoothScrollTo(0, 0)
            Toast.makeText(this, "Finish the setup first (accessibility and display over apps)", Toast.LENGTH_LONG).show()
            return
        }
        pendingGame = g
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            val pkg = pendingGame?.pkg ?: "com.RayGaming.ForestCleaner"
            val game = packageManager.getLaunchIntentForPackage(pkg)
            if (game != null) {
                startActivity(game)
            } else {
                Toast.makeText(this, "Game is not installed - open it yourself", Toast.LENGTH_LONG).show()
            }
        }
    }
}
