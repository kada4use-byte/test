package com.forestbot

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private class Game(val name: String, val pkg: String, val blurb: String, val garden: Boolean = false)

    private val games = listOf(
        Game("Forest Cleaner", "com.RayGaming.ForestCleaner", "Collects litter and coins, dodges obstacles"),
        Game("Garden Fill", "", "Solves every puzzle: one swipe fills the whole garden", garden = true)
    )

    private fun isRunning() = BotService.running || GardenBot.running

    /** Finds an installed app by its name (Garden Fill's package name is not known in advance). */
    private fun findPackage(label: String): String? {
        return try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            packageManager.queryIntentActivities(i, 0)
                .firstOrNull { it.loadLabel(packageManager).toString().equals(label, true) }
                ?.activityInfo?.packageName
        } catch (e: Exception) {
            null
        }
    }

    private val BG = Color.rgb(15, 17, 21)
    private val CARD = Color.rgb(27, 31, 39)
    private val TEXT = Color.WHITE
    private val SUB = Color.rgb(150, 158, 172)
    private val ACCENT = Color.rgb(34, 211, 238)
    private val GOOD = Color.rgb(163, 230, 53)
    private val WARN = Color.rgb(251, 146, 60)

    private val reqCapture = 1001
    private var pendingGame: Game? = null
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private var showSetup = false
    private var lastKey = ""
    private lateinit var logView: TextView
    private lateinit var statusView: TextView
    private lateinit var aiStatusView: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun round(color: Int, radius: Int): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = dp(radius).toFloat()
        return g
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        scroll = ScrollView(this)
        scroll.setBackgroundColor(BG)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(18), dp(40), dp(18), dp(28))
        scroll.addView(content)
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onResume() {
        super.onResume()
        lastKey = ""
        ticker.run()
    }

    override fun onPause() {
        handler.removeCallbacks(ticker)
        super.onPause()
    }

    private fun accOn() = GameAccessibilityService.instance != null
    private fun overlayOn() = Settings.canDrawOverlays(this)
    private fun ready() = accOn() && overlayOn()

    private fun refresh() {
        val key = "${accOn()}|${overlayOn()}|${isRunning()}|$showSetup|${RunRecorder.runFiles(this).size}|${RunRecorder.sentFiles(this).size}|${RunRecorder.fps(this)}|$exporting"
        if (key != lastKey) {
            lastKey = key
            build()
        }
        statusView.text = if (BotService.running) BotService.status else if (GardenBot.running) GardenBot.status else ""
        if (this::aiStatusView.isInitialized) aiStatusView.text = Gemini.status + (if (Gemini.calls > 0) "  (${Gemini.calls} calls)" else "")
        logView.text = AppLog.tail(this, 12).ifEmpty { "(nothing yet)" }
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        c.background = round(CARD, 18)
        c.setPadding(dp(16), dp(14), dp(16), dp(14))
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.setMargins(0, 0, 0, dp(12))
        c.layoutParams = lp
        return c
    }

    private fun pill(label: String, color: Int, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.setTextColor(Color.BLACK)
        b.textSize = 14f
        b.background = round(color, 20)
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(16), dp(8), dp(16), dp(8))
        b.setOnClickListener { onClick() }
        return b
    }

    private fun setupRow(parent: LinearLayout, ok: Boolean, title: String, hint: String, action: String, onClick: () -> Unit) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(8), 0, dp(8))
        val dot = View(this)
        dot.background = round(if (ok) GOOD else WARN, 8)
        row.addView(dot, LinearLayout.LayoutParams(dp(12), dp(12)))
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), 0, dp(8), 0)
        col.addView(text(title, 15f, TEXT, true))
        col.addView(text(hint, 12f, SUB))
        row.addView(col, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(pill(if (ok) "Done" else action, if (ok) Color.rgb(90, 98, 112) else ACCENT, onClick))
        parent.addView(row)
    }

    private fun lpWrap(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(top); l.bottomMargin = dp(bottom)
        return l
    }

    private fun lpFull(top: Int = 0, bottom: Int = 0): LinearLayout.LayoutParams {
        val l = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        l.topMargin = dp(top); l.bottomMargin = dp(bottom)
        return l
    }

    /** Full-width button: [fill] true = solid colour, false = outlined. */
    private fun wide(label: String, color: Int, fill: Boolean, onClick: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.isAllCaps = false
        b.textSize = 15f
        b.setTypeface(null, Typeface.BOLD)
        b.minHeight = 0
        b.minimumHeight = 0
        b.setPadding(dp(16), dp(13), dp(16), dp(13))
        if (fill) {
            b.setTextColor(Color.rgb(10, 14, 20))
            b.background = round(color, 14)
        } else {
            b.setTextColor(color)
            val g = round(Color.TRANSPARENT, 14)
            g.setStroke(dp(1), color)
            b.background = g
        }
        b.setOnClickListener { onClick() }
        return b
    }

    private fun tile(value: String, label: String, color: Int): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.gravity = Gravity.CENTER
        t.background = round(Color.rgb(34, 39, 49), 14)
        t.setPadding(dp(6), dp(12), dp(6), dp(12))
        t.addView(text(value, 22f, color, true).also { it.gravity = Gravity.CENTER })
        t.addView(text(label, 11f, SUB).also { it.gravity = Gravity.CENTER })
        return t
    }

    private fun sectionLabel(s: String): TextView {
        val t = text(s.uppercase(), 11f, SUB, true)
        t.letterSpacing = 0.12f
        t.setPadding(dp(4), dp(10), 0, dp(8))
        return t
    }

    private fun build() {
        content.removeAllViews()
        val ok = ready()
        val steps = listOf(accOn(), overlayOn())
        val runs = RunRecorder.runFiles(this)
        val sent = RunRecorder.sentFiles(this)
        val waitMb = runs.sumOf { it.length() } / (1024.0 * 1024.0)
        val ver = RunRecorder.versionName(this)

        // ---- header
        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val logo = ImageView(this)
        logo.setImageResource(R.drawable.ic_fg)
        logo.background = round(Color.rgb(15, 27, 45), 16)
        head.addView(logo, LinearLayout.LayoutParams(dp(54), dp(54)))
        val ht = LinearLayout(this)
        ht.orientation = LinearLayout.VERTICAL
        ht.setPadding(dp(14), 0, 0, 0)
        ht.addView(text("OxyDoxy", 28f, TEXT, true))
        ht.addView(text("Your phone plays games for you", 13f, SUB))
        head.addView(ht, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        val chip = text("v$ver", 12f, ACCENT, true)
        chip.background = round(Color.rgb(16, 52, 62), 12)
        chip.setPadding(dp(10), dp(5), dp(10), dp(5))
        head.addView(chip)
        content.addView(head, lpFull(0, 18))

        // ---- hero: what is happening now + the game picker
        val hero = LinearLayout(this)
        hero.orientation = LinearLayout.VERTICAL
        val grad = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            if (isRunning()) intArrayOf(Color.rgb(20, 83, 45), Color.rgb(15, 52, 70))
            else if (accOn()) intArrayOf(Color.rgb(24, 42, 92), Color.rgb(46, 26, 84))
            else intArrayOf(Color.rgb(92, 52, 20), Color.rgb(48, 30, 20))
        )
        grad.cornerRadius = dp(22).toFloat()
        hero.background = grad
        hero.setPadding(dp(18), dp(18), dp(18), dp(18))
        val dotRow = LinearLayout(this)
        dotRow.gravity = Gravity.CENTER_VERTICAL
        val dot = View(this)
        dot.background = round(if (isRunning()) GOOD else if (accOn()) ACCENT else WARN, 8)
        dotRow.addView(dot, LinearLayout.LayoutParams(dp(10), dp(10)))
        dotRow.addView(text(
            if (isRunning()) "RUNNING" else if (accOn()) "READY" else "SETUP NEEDED", 12f,
            Color.argb(230, 255, 255, 255), true).also { it.letterSpacing = 0.14f; it.setPadding(dp(8), 0, 0, 0) })
        hero.addView(dotRow)
        statusView = text("", 12f, Color.argb(190, 255, 255, 255))
        if (isRunning()) {
            hero.addView(text(if (GardenBot.running) "Playing Garden Fill" else "Playing Forest Cleaner", 24f, TEXT, true)
                .also { it.setPadding(0, dp(8), 0, 0) })
            statusView.setPadding(0, dp(4), 0, dp(14))
            hero.addView(statusView)
            hero.addView(wide("Stop the bot", Color.rgb(248, 113, 113), true) {
                if (GardenBot.running) GardenBot.stop()
                stopService(Intent(this, BotService::class.java))
                lastKey = ""
            })
        } else {
            hero.addView(text(if (accOn()) "Pick a game" else "Finish setup to start", 24f, TEXT, true)
                .also { it.setPadding(0, dp(8), 0, 0) })
            hero.addView(text(
                if (accOn()) "OxyDoxy plays it for you. Tap Start on a game." else "Turn on Accessibility (see Setup below), then pick a game.",
                13f, Color.argb(190, 255, 255, 255)).also { it.setPadding(0, dp(4), 0, dp(14)) })
            val tiles = LinearLayout(this)
            tiles.orientation = LinearLayout.HORIZONTAL
            for ((i, g) in games.withIndex()) {
                val l = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                if (i < games.size - 1) l.rightMargin = dp(10)
                tiles.addView(gameTile(g), l)
            }
            hero.addView(tiles)
        }
        content.addView(hero, lpFull(0, 14))

        // ---- stats
        val stats = LinearLayout(this)
        stats.orientation = LinearLayout.HORIZONTAL
        fun addTile(t: View, last: Boolean = false) {
            val l = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            if (!last) l.rightMargin = dp(8)
            stats.addView(t, l)
        }
        addTile(tile("${GardenBot.totalSolved(this)}", "garden levels solved", GOOD))
        addTile(tile("${runs.size}", "runs waiting", ACCENT))
        addTile(tile("${"%.0f".format(waitMb)} MB", "to export", Color.WHITE), true)
        content.addView(stats, lpFull(0, 14))

        // ---- setup (auto-collapses when done)
        if (!ok || showSetup) {
            val sc = card()
            sc.addView(text("Setup", 18f, TEXT, true))
            sc.addView(text("Do these once. Each button opens the right Settings page.", 12f, SUB))
            setupRow(sc, false, "1. Allow restricted settings", "Do this first if Accessibility is greyed out", "Open") {
                startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
            }
            setupRow(sc, accOn(), "2. Accessibility", "Turn on OxyDoxy so it can tap for you", "Open") {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
            setupRow(sc, overlayOn(), "3. Display over other apps", "Shows the boxes and the Pause / Stop buttons", "Allow") {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            setupRow(sc, false, "4. Battery: Unrestricted", "Stops the phone from killing the bot", "Open") {
                try {
                    startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
                }
            }
            if (ok) sc.addView(pill("Hide setup", Color.rgb(90, 98, 112)) { showSetup = false; lastKey = "" }, lpWrap(8))
            content.addView(sc)
        }

        // ---- AI helper
        content.addView(sectionLabel("AI helper"))
        val ai = card()
        val aiKeys = AiKeys.keys(this)
        ai.addView(text(if (aiKeys.isEmpty()) "No key yet" else "${aiKeys.size} key${if (aiKeys.size > 1) "s" else ""} · tried in this order", 16f, TEXT, true))
        ai.addView(text(
            "When the bot meets a screen it does not know (an ad, a pop-up, a glitch) it takes a screenshot every 2 seconds and asks Google Gemini what to do. " +
                "If a key fails or is out of free quota, the next key is used. Get free keys at aistudio.google.com/apikey (one per Google account/project).",
            12f, SUB).also { it.setPadding(0, dp(4), 0, dp(6)) })
        aiKeys.forEachIndexed { i, k ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            val t = text("${i + 1}.  ••••${k.takeLast(4)}", 14f, TEXT)
            row.addView(t, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            if (i > 0) row.addView(pill("↑", Color.rgb(170, 178, 192)) { AiKeys.moveUp(this, i); lastKey = "" })
            val rm = pill("Remove", Color.rgb(248, 113, 113)) { AiKeys.remove(this, i); lastKey = "" }
            row.addView(rm, lpWrap().also { it.leftMargin = dp(8) })
            ai.addView(row, lpFull(6))
        }
        ai.addView(wide("Add a key", ACCENT, true) {
            val et = EditText(this)
            et.hint = "Paste the API key here"
            et.setSingleLine(true)
            android.app.AlertDialog.Builder(this)
                .setTitle("Add Google AI Studio key")
                .setView(et)
                .setPositiveButton("Add") { _, _ ->
                    if (!AiKeys.add(this, et.text.toString())) Toast.makeText(this, "Not added (empty, too short or already there)", Toast.LENGTH_LONG).show()
                    lastKey = ""
                }
                .setNegativeButton("Cancel", null)
                .show()
        }, lpFull(10))
        ai.addView(wide("Model: ${AiKeys.model(this)}", Color.rgb(170, 178, 192), false) {
            val et = EditText(this)
            et.setSingleLine(true)
            et.setText(AiKeys.model(this))
            android.app.AlertDialog.Builder(this)
                .setTitle("Gemini model name")
                .setMessage("Default: ${AiKeys.DEFAULT_MODEL}")
                .setView(et)
                .setPositiveButton("Save") { _, _ -> AiKeys.setModel(this, et.text.toString()); lastKey = "" }
                .setNegativeButton("Cancel", null)
                .show()
        }, lpFull(8))
        ai.addView(wide("Test the AI", GOOD, true) {
            Toast.makeText(this, "Testing...", Toast.LENGTH_SHORT).show()
            Thread {
                val r = Gemini.test(this)
                runOnUiThread {
                    android.app.AlertDialog.Builder(this).setTitle("AI test").setMessage(r).setPositiveButton("OK", null).show()
                }
            }.start()
        }, lpFull(8))
        aiStatusView = text(Gemini.status, 11f, Color.rgb(110, 118, 132))
        aiStatusView.setPadding(0, dp(8), 0, 0)
        ai.addView(aiStatusView)
        content.addView(ai)

        // ---- run data
        content.addView(sectionLabel("Run data"))
        val rc = card()
        rc.addView(text(
            if (runs.isEmpty() && sent.isEmpty()) "No runs saved yet" else "${runs.size} waiting  ·  ${sent.size} already sent",
            16f, TEXT, true))
        rc.addView(text(
            if (exporting) "Packing... this can take a minute"
            else "Every run is saved frame by frame (up to ${RunRecorder.MAX_RUNS}), even if you stop and restart the bot. " +
                "Each frame is stamped with the app version. Exports are split into parts of at most $PART_MB MB so they fit the 30 MB upload limit.",
            12f, SUB).also { it.setPadding(0, dp(4), 0, 0) })
        if (!exporting) {
            rc.addView(wide("Export next part  (≤ $PART_MB MB)", ACCENT, true) { exportPart() }, lpFull(12))
            val two = LinearLayout(this)
            two.orientation = LinearLayout.HORIZONTAL
            val a = wide("Data only", ACCENT, false) { exportData() }
            val b = wide("${RunRecorder.fps(this)} fps ↻", Color.rgb(170, 178, 192), false) {
                RunRecorder.nextFps(this)
                lastKey = ""
            }
            val l1 = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f); l1.rightMargin = dp(8)
            two.addView(a, l1)
            two.addView(b, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            rc.addView(two, lpFull(8))
            rc.addView(text("Data only = tiny file with positions, no images. fps: lower = smaller files (60 = every frame, 20 = about 2 MB per run).",
                11f, Color.rgb(110, 118, 132)).also { it.setPadding(0, dp(6), 0, 0) })
            if (sent.isNotEmpty()) rc.addView(wide("Delete the ${sent.size} sent runs", Color.rgb(248, 113, 113), false) {
                for (f in RunRecorder.sentFiles(this)) try { f.delete() } catch (_: Exception) {}
                lastKey = ""
            }, lpFull(10))
            if (runs.isNotEmpty() || sent.isNotEmpty()) rc.addView(wide("Delete everything saved", Color.rgb(248, 113, 113), false) {
                android.app.AlertDialog.Builder(this)
                    .setTitle("Delete all saved runs?")
                    .setMessage("This removes ${runs.size + sent.size} runs from the phone. It cannot be undone.")
                    .setPositiveButton("Delete") { _, _ ->
                        for (f in RunRecorder.runFiles(this) + RunRecorder.sentFiles(this)) try { f.delete() } catch (_: Exception) {}
                        lastKey = ""
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }, lpFull(8))
        }
        content.addView(rc)

        // ---- log
        content.addView(sectionLabel("Activity"))
        val lg = card()
        logView = text("", 11f, Color.rgb(170, 178, 192))
        logView.typeface = Typeface.MONOSPACE
        lg.addView(logView)
        content.addView(lg)
    }

    @Volatile
    private var exporting = false

    private val PART_MB = 25

    /** Creates a zip in Download/ForestBot and gives [fill] the stream to write into. Returns its Uri. */
    private fun newExportFile(name: String, fill: (java.util.zip.ZipOutputStream) -> Unit): Uri {
        val uri: Uri
        val os: java.io.OutputStream
        if (Build.VERSION.SDK_INT >= 29) {
            val v = android.content.ContentValues()
            v.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, "$name.zip")
            v.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/zip")
            v.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/ForestBot")
            v.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 1)
            val u = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("cannot create the export file")
            uri = u
            os = contentResolver.openOutputStream(u) ?: throw IllegalStateException("cannot open the export file")
        } else {
            val dir = java.io.File(getExternalFilesDir(null), "export")
            dir.mkdirs()
            val f = java.io.File(dir, "$name.zip")
            uri = Uri.fromFile(f)
            os = f.outputStream()
        }
        val z = java.util.zip.ZipOutputStream(os.buffered(1 shl 20))
        z.setLevel(java.util.zip.Deflater.NO_COMPRESSION)
        fill(z)
        z.close()
        if (Build.VERSION.SDK_INT >= 29) {
            val done = android.content.ContentValues()
            done.put(android.provider.MediaStore.MediaColumns.IS_PENDING, 0)
            contentResolver.update(uri, done, null, null)
        }
        return uri
    }

    private fun stamp() = java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.US).format(java.util.Date())

    private fun finishExport(uri: Uri?, err: String, doneMsg: String) {
        exporting = false
        handler.post {
            lastKey = ""
            if (err.isNotEmpty() || uri == null) {
                Toast.makeText(this, "Export failed: $err", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, doneMsg, Toast.LENGTH_LONG).show()
                try {
                    val i = Intent(Intent.ACTION_SEND)
                    i.type = "application/zip"
                    i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Send this part"))
                } catch (e: Exception) {
                    Toast.makeText(this, "Saved in Download/ForestBot", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    /** Packs the oldest waiting runs into ONE zip of at most PART_MB, marks them as sent, and offers to share it. */
    private fun exportPart() {
        if (exporting) return
        exporting = true
        lastKey = ""
        Thread {
            var uri: Uri? = null
            var err = ""
            var msg = ""
            try {
                val limit = PART_MB * 1024L * 1024L
                val chosen = ArrayList<java.io.File>()
                var total = 0L
                for (f in RunRecorder.runFiles(this)) {
                    if (chosen.isNotEmpty() && total + f.length() > limit) break
                    chosen.add(f)
                    total += f.length()
                }
                if (chosen.isEmpty()) throw IllegalStateException("no runs waiting")
                val leftBefore = RunRecorder.runFiles(this).size - chosen.size
                uri = newExportFile("forestbot_part_" + stamp()) { z ->
                    for (f in chosen) {
                        z.putNextEntry(java.util.zip.ZipEntry(f.name))
                        f.inputStream().use { it.copyTo(z, 1 shl 16) }
                        z.closeEntry()
                    }
                }
                for (f in chosen) {
                    try { f.renameTo(java.io.File(f.parentFile, f.name.removeSuffix(".zip") + ".sent")) } catch (_: Exception) {}
                }
                msg = "${chosen.size} runs, ${total / (1024 * 1024)} MB. $leftBefore runs still waiting."
                AppLog.add("exported part: $msg")
            } catch (e: Throwable) {
                err = e.toString()
                AppLog.add("export failed: $e")
            }
            finishExport(uri, err, msg)
        }.start()
    }

    /** One small zip with only data.csv / frames.csv / info.txt of EVERY saved run (no images). */
    private fun exportData() {
        if (exporting) return
        exporting = true
        lastKey = ""
        Thread {
            var uri: Uri? = null
            var err = ""
            var msg = ""
            try {
                val files = (RunRecorder.runFiles(this) + RunRecorder.sentFiles(this)).sortedBy { it.name }
                if (files.isEmpty()) throw IllegalStateException("no runs saved yet")
                var n = 0
                uri = newExportFile("forestbot_data_" + stamp()) { z ->
                    z.setLevel(java.util.zip.Deflater.BEST_COMPRESSION)
                    for (f in files) {
                        try {
                            java.util.zip.ZipFile(f).use { zf ->
                                val base = f.name.removeSuffix(".zip").removeSuffix(".sent")
                                for (en in listOf("data.csv", "frames.csv", "info.txt")) {
                                    val e = zf.getEntry(en) ?: continue
                                    z.putNextEntry(java.util.zip.ZipEntry(base + "/" + en))
                                    zf.getInputStream(e).use { it.copyTo(z, 1 shl 15) }
                                    z.closeEntry()
                                }
                                n++
                            }
                        } catch (_: Exception) {
                            // a run that was cut off (app killed while recording) has no index: skip it
                        }
                    }
                }
                msg = "data of $n runs"
                AppLog.add("exported data only: $msg")
            } catch (e: Throwable) {
                err = e.toString()
                AppLog.add("export failed: $e")
            }
            finishExport(uri, err, msg)
        }.start()
    }

    /** One game inside the hero card: icon, name, what it does, and its own Start button. */
    private fun gameTile(g: Game): LinearLayout {
        val t = LinearLayout(this)
        t.orientation = LinearLayout.VERTICAL
        t.background = round(Color.argb(46, 255, 255, 255), 18)
        t.setPadding(dp(12), dp(14), dp(12), dp(12))
        val icon = ImageView(this)
        var installed = true
        try {
            icon.setImageDrawable(packageManager.getApplicationIcon(pkgOf(g).ifEmpty { "none.installed" }))
        } catch (e: Exception) {
            installed = false
            icon.setImageResource(R.drawable.ic_fg)
            icon.background = round(Color.rgb(15, 27, 45), 14)
        }
        t.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
        t.addView(text(g.name, 16f, TEXT, true).also { it.setPadding(0, dp(10), 0, 0) })
        t.addView(text(if (installed) g.blurb else "Not installed on this phone", 11f, Color.argb(190, 255, 255, 255))
            .also { it.minLines = 3; it.setPadding(0, dp(2), 0, dp(10)) })
        val canStart = installed && (if (g.garden) accOn() else ready())
        val label = if (!installed) "Not installed" else if (canStart) "Start" else "Setup first"
        val color = if (!installed) Color.rgb(90, 98, 112) else if (canStart) GOOD else WARN
        t.addView(wide(label, color, true) {
            if (!installed) return@wide
            if (!canStart) { showSetup = true; lastKey = ""; scroll.smoothScrollTo(0, 0) } else startGame(g)
        })
        return t
    }

    private fun pkgOf(g: Game): String = if (g.garden) (findPackage(g.name) ?: "") else g.pkg

    /** Garden Fill needs no screen capture: it uses accessibility screenshots, so it starts right away. */
    private fun startGarden(g: Game) {
        val svc = GameAccessibilityService.instance
        if (svc == null) {
            showSetup = true
            lastKey = ""
            Toast.makeText(this, "Turn on Accessibility for OxyDoxy first (see Setup)", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT < 30) {
            Toast.makeText(this, "Garden Fill needs Android 11 or newer", Toast.LENGTH_LONG).show()
            return
        }
        val pkg = pkgOf(g)
        val launch = if (pkg.isEmpty()) null else packageManager.getLaunchIntentForPackage(pkg)
        if (launch == null) {
            Toast.makeText(this, "Garden Fill is not installed", Toast.LENGTH_LONG).show()
            return
        }
        GardenBot.start(svc, applicationContext, pkg)
        lastKey = ""
        startActivity(launch)
    }

    private fun startGame(g: Game) {
        if (g.garden) {
            if (isRunning()) {
                Toast.makeText(this, "Already running. Press Stop first.", Toast.LENGTH_SHORT).show()
            } else {
                startGarden(g)
            }
            return
        }
        if (isRunning()) {
            Toast.makeText(this, "Already running. Press Stop first.", Toast.LENGTH_SHORT).show()
            return
        }
        if (!ready()) {
            showSetup = true
            lastKey = ""
            scroll.smoothScrollTo(0, 0)
            Toast.makeText(this, "Finish the setup first (accessibility and display over apps)", Toast.LENGTH_LONG).show()
            return
        }
        pendingGame = g
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture && resultCode == RESULT_OK && data != null) {
            val i = Intent(this, BotService::class.java)
            i.putExtra("code", resultCode)
            i.putExtra("data", data)
            startForegroundService(i)
            val pkg = pendingGame?.pkg ?: "com.RayGaming.ForestCleaner"
            val game = packageManager.getLaunchIntentForPackage(pkg)
            if (game != null) {
                startActivity(game)
            } else {
                Toast.makeText(this, "Game is not installed - open it yourself", Toast.LENGTH_LONG).show()
            }
        }
    }
}
