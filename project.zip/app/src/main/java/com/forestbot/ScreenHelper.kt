package com.forestbot

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import java.io.ByteArrayOutputStream

/**
 * Handles every screen the bot does not recognise (ads, pop-ups, glitches). Shared by both games.
 * It does NOT block or skip ads: ads are left to finish (the reward needs the full ad). It only
 * presses a close button once the ad is over, and gets the game back if something went wrong.
 *
 * With AI keys set: a screenshot is taken every 2 s; after 3 s on an unknown screen the last 3 frames
 * go to Gemini, which answers with one action (tap here / back / relaunch / wait). The result is
 * checked on the next frames and the AI is told what was already tried.
 * Without a key, or if every key fails: it only waits (nothing is tapped blindly).
 * Always: if an ad opened another app, Back / relaunch; if stuck for two minutes, relaunch the game.
 */
class ScreenHelper(private val svc: GameAccessibilityService, private val ctx: Context, private val pkg: String) {
    private var since = 0L
    private var tries = 0
    private var lastTry = 0L
    private var backs = 0

    private val frames = ArrayList<ByteArray>()
    private var lastShotT = 0L
    private var lastSig: IntArray? = null
    private var sigAtAi: IntArray? = null
    private var lastAiT = 0L
    private var lastAiOk = 0L
    private var staticSince = 0L
    private var dim = false
    private var sw = 1080
    private var sh = 2400
    private val tried = ArrayList<String>()

    companion object {
        const val SHOT_MS = 2_000L        // a screenshot every 2 s
        const val AI_START_MS = 3_000L    // ask the AI after this long on an unknown screen
        const val AI_EVERY_MS = 4_000L
        const val DIM_HOLD_MS = 15_000L   // dim 'Ad Break' screens: wait this long before asking
        const val WAIT_MS = 12_000L       // fixed rules (no AI): do nothing for this long
        const val RETRY_MS = 6_000L
        const val RELAUNCH_MS = 120_000L
        const val BACK_AFTER_MS = 30_000L  // the AI may press Back only after this long (Back can end an ad early)
    }

    fun reset() {
        since = 0L; tries = 0; backs = 0; lastTry = 0L
        frames.clear(); tried.clear(); lastSig = null; sigAtAi = null; lastShotT = 0L; lastAiT = 0L
    }

    /** True when some other app (browser, store) is in front instead of the game. */
    private fun away(): Boolean {
        val fg = svc.windowPkg
        return fg.isNotEmpty() && fg != pkg && fg != ctx.packageName &&
            !fg.startsWith("com.android.systemui") && fg != "android"
    }

    fun relaunch() {
        try {
            val li = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return
            li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            ctx.startActivity(li)
        } catch (_: Exception) {
        }
    }

    /** Takes a screenshot, keeps the last 3 as small JPEGs, and remembers a tiny fingerprint of it. */
    private var warnedNoShot = false

    private fun capture(now: Long, given: GameAccessibilityService.Shot?) {
        lastShotT = now
        // A bot that already takes screenshots passes its latest one: Android refuses two screenshots
        // within about a second, so taking our own at the same time would often fail.
        val s = given ?: svc.screenshot()
        if (s == null) {
            if (!warnedNoShot) { warnedNoShot = true; AppLog.add("AI helper: could not get a screenshot") }
            return
        }
        sw = s.w; sh = s.h
        val opaque = IntArray(s.px.size) { s.px[it] or (0xFF shl 24) }
        val bmp = Bitmap.createBitmap(opaque, s.w, s.h, Bitmap.Config.ARGB_8888)
        // fingerprint: 12x12 grid of brightness, and average brightness
        val sig = IntArray(144)
        var sum = 0L
        for (gy in 0 until 12) for (gx in 0 until 12) {
            val px = s.px[((gy * s.h / 12 + s.h / 24) * s.w) + gx * s.w / 12 + s.w / 24]
            val l = ((px shr 16 and 255) * 3 + (px shr 8 and 255) * 6 + (px and 255)) / 10
            sig[gy * 12 + gx] = l
            sum += l
        }
        val prev = lastSig
        if (prev == null || sigDiff(prev, sig) > 3) staticSince = now
        lastSig = sig
        dim = sum / 144 < 70
        val tw = 480
        val th = s.h * tw / s.w
        val small = Bitmap.createScaledBitmap(bmp, tw, th, true)
        val out = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 70, out)
        frames.add(out.toByteArray())
        while (frames.size > 3) frames.removeAt(0)
        bmp.recycle()
        if (small !== bmp) small.recycle()
    }

    private fun sigDiff(a: IntArray, b: IntArray): Int {
        var d = 0
        for (i in a.indices) d += Math.abs(a[i] - b[i])
        return d / a.size
    }

    private fun changed(): Boolean {
        val a = lastSig ?: return true
        val b = sigAtAi ?: return true
        var d = 0
        for (i in a.indices) d += Math.abs(a[i] - b[i])
        return d / a.size > 4
    }

    private fun act(d: Decision, now: Long) {
        val desc = "${d.action}${if (d.action == "tap") " (%.2f,%.2f)".format(d.x, d.y) else ""} on '${d.desc}'"
        when (d.action) {
            "tap" -> {
                if (d.x in 0f..1f && d.y in 0f..0.9f) {
                    svc.tap(d.x * sw, d.y * sh)
                } else {
                    AppLog.add("AI: refused tap at (%.2f,%.2f) (outside the safe area)".format(d.x, d.y))
                    tried.add("tap refused (bottom edge / invalid)")
                    return
                }
            }
            "back" -> {
                if (now - since < BACK_AFTER_MS && !away()) {
                    AppLog.add("AI: Back refused (the ad may still be playing)")
                    tried.add("back refused: wait for the ad to finish")
                    return
                }
                svc.back()
            }
            "relaunch" -> { relaunch(); since = now; backs = 0 }
            else -> {}
        }
        tried.add(desc)
        while (tried.size > 6) tried.removeAt(0)
        AppLog.add("AI [${d.screen}] $desc - ${d.reason}")
    }

    /** Call about every second while the screen is not one the bot knows. Returns how long it has been (ms). */
    fun step(now: Long, w: Float, h: Float, shot: GameAccessibilityService.Shot? = null): Long {
        if (since == 0L) since = now
        val waited = now - since

        if (away()) {
            // an ad was clicked and opened another app
            if (waited > 3000 && now - lastTry > 2500) {
                lastTry = now
                backs++
                if (backs >= 3) {
                    AppLog.add("ads: still away, bringing the game back")
                    relaunch()
                    backs = 0
                } else {
                    svc.back()
                }
            }
            return waited
        }

        if (now - lastShotT >= SHOT_MS) capture(now, shot)

        val haveAi = AiKeys.keys(ctx).isNotEmpty()
        if (haveAi && waited >= AI_START_MS && frames.isNotEmpty() && now - lastAiT >= AI_EVERY_MS &&
            (!dim || waited >= DIM_HOLD_MS) && (changed() || now - lastAiT >= (if (now - staticSince > 30_000L) 15_000L else 5_000L))) {
            sigAtAi = lastSig
            val d = Gemini.ask(ctx, ArrayList(frames), ArrayList(tried),
                "On this unknown screen for ${waited / 1000}s. The picture has not changed for ${(now - staticSince) / 1000}s.")
            lastAiT = now
            if (d != null) {
                lastAiOk = now
                act(d, now)
            } else {
                lastAiOk = 0L
            }
            return waited
        }
        if (waited > RELAUNCH_MS) {
            AppLog.add("ads: stuck for ${waited / 1000}s, starting the game again")
            relaunch()
            since = now
            tries = 0
            backs = 0
            tried.add("relaunched the game")
        }
        return waited
    }
}
