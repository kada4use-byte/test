package com.forestbot

import kotlin.math.max
import kotlin.math.min

/**
 * Reads the numbers on the Forest Cleaner home screen (distance, bin size, upgrade prices, coins)
 * from a full-size screenshot. Digits are cut out one by one and matched against sample
 * digits in [Digits].
 */
object MenuReader {

    class Menu(val dist: Int, val cap: Int, val coins: Int, val costD: Int, val costT: Int) {
        override fun toString() = "dist=$dist cap=$cap coins=$coins costDist=$costD costTrash=$costT"
    }

    const val TW = 8
    const val TH = 12

    // screen regions (fractions of the whole screen) that hold each number
    private val R_DIST = floatArrayOf(0.0926f, 0.5883f, 0.4676f, 0.6150f)
    private val R_CAP = floatArrayOf(0.5278f, 0.5883f, 0.8796f, 0.6150f)
    private val R_COINS = floatArrayOf(0.310f, 0.7690f, 0.644f, 0.7979f)
    private val R_COST_D = floatArrayOf(0.213f, 0.665f, 0.398f, 0.6825f)
    private val R_COST_T = floatArrayOf(0.676f, 0.665f, 0.838f, 0.6825f)

    // where to tap
    const val BTN_Y = 0.704f
    const val BTN_DIST_X = 0.273f
    const val BTN_TRASH_X = 0.727f

    fun read(px: IntArray, w: Int, h: Int): Menu = Menu(
        number(px, w, h, R_DIST),
        number(px, w, h, R_CAP),
        number(px, w, h, R_COINS),
        number(px, w, h, R_COST_D),
        number(px, w, h, R_COST_T)
    )

    private fun lum(p: Int): Int {
        val r = (p shr 16) and 255
        val g = (p shr 8) and 255
        val b = p and 255
        return (r * 299 + g * 587 + b * 114) / 1000
    }

    /** Cuts out the glyphs in a region and returns one small thumbnail (TW x TH, values 0..1) per glyph. */
    fun glyphs(px: IntArray, w: Int, h: Int, reg: FloatArray): List<FloatArray> {
        val x0 = (reg[0] * w).toInt().coerceIn(0, w - 1)
        val y0 = (reg[1] * h).toInt().coerceIn(0, h - 1)
        val x1 = (reg[2] * w).toInt().coerceIn(x0 + 1, w)
        val y1 = (reg[3] * h).toInt().coerceIn(y0 + 1, h)
        var mx = 0
        for (y in y0 until y1) for (x in x0 until x1) mx = max(mx, lum(px[y * w + x]))
        if (mx < 170) return emptyList()
        val thr = (mx * 0.78f).toInt()
        val cw = x1 - x0
        val col = BooleanArray(cw)
        for (x in x0 until x1) {
            for (y in y0 until y1) if (lum(px[y * w + x]) >= thr) { col[x - x0] = true; break }
        }
        val out = ArrayList<FloatArray>()
        var i = 0
        while (i < cw) {
            if (!col[i]) { i++; continue }
            var j = i
            while (j < cw && col[j]) j++
            // glyph occupies columns i until j
            var ya = y1
            var yb = y0
            for (y in y0 until y1) for (x in x0 + i until x0 + j) {
                if (lum(px[y * w + x]) >= thr) { ya = min(ya, y); yb = max(yb, y) }
            }
            val gh = yb - ya + 1
            val gw = j - i
            if (gh >= (y1 - y0) * 0.35f && gw >= 2) {
                val t = FloatArray(TW * TH)
                for (ty in 0 until TH) for (tx in 0 until TW) {
                    val sx0 = x0 + i + tx * gw / TW
                    val sx1 = max(sx0 + 1, x0 + i + (tx + 1) * gw / TW)
                    val sy0 = ya + ty * gh / TH
                    val sy1 = max(sy0 + 1, ya + (ty + 1) * gh / TH)
                    var s = 0f
                    var n = 0
                    for (yy in sy0 until min(sy1, y1)) for (xx in sx0 until min(sx1, x1)) {
                        s += if (lum(px[yy * w + xx]) >= thr) 1f else 0f
                        n++
                    }
                    t[ty * TW + tx] = if (n > 0) s / n else 0f
                }
                out.add(t)
            }
            i = j
        }
        return out
    }

    fun glyphsOf(px: IntArray, w: Int, h: Int, which: Int): List<FloatArray> =
        glyphs(px, w, h, arrayOf(R_DIST, R_CAP, R_COINS, R_COST_D, R_COST_T)[which])

    private fun number(px: IntArray, w: Int, h: Int, reg: FloatArray): Int {
        val gs = glyphs(px, w, h, reg)
        if (gs.isEmpty() || gs.size > 7) return -1
        var v = 0L
        for (g in gs) {
            var best = 1e9f
            var bc = -1
            for ((c, t) in Digits.lib) {
                var d = 0f
                for (k in g.indices) { val e = g[k] - t[k]; d += e * e }
                if (d < best) { best = d; bc = c }
            }
            if (bc < 0 || best > 14f) return -1
            v = v * 10 + bc
        }
        return v.toInt()
    }
}
