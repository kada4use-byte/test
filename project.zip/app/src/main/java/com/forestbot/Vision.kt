package com.forestbot

import kotlin.math.abs

enum class Screen { MENU, RESULT, GAME, UNKNOWN }

/**
 * Looks at one small screenshot and works out
 *  - which screen the game is on (menu / result / playing / unknown)
 *  - where the bin, litter, coins and hazards (animals, stumps) are.
 *
 * All pixels are packed as 0xRRGGBB ints. Positions of objects are fractions of the
 * game area (the part of the screen that is not black bars).
 */
object Vision {
    const val COIN = 0
    const val LITTER = 1
    const val HAZARD = 2

    class Obj(val kind: Int, val cx: Float, val cy: Float, val w: Float, val h: Float)

    class Analysis(
        val screen: Screen,
        val top: Int,
        val bottom: Int,
        val tapX: Float,      // fraction of the full frame, for MENU / RESULT
        val tapY: Float,
        val binX: Float,      // fractions of the game area, -1 if bin not found
        val binY: Float,
        val binW: Float,
        val objs: List<Obj>
    )

    private fun rr(p: Int) = (p shr 16) and 255
    private fun gg(p: Int) = (p shr 8) and 255
    private fun bb(p: Int) = p and 255

    private class Comp {
        var area = 0
        var sx = 0L
        var sy = 0L
        var x0 = Int.MAX_VALUE
        var x1 = -1
        var y0 = Int.MAX_VALUE
        var y1 = -1
        var gold = 0
    }

    private fun components(mask: BooleanArray, w: Int, h: Int, gold: BooleanArray?): List<Comp> {
        val seen = BooleanArray(w * h)
        val stack = IntArray(w * h)
        val out = ArrayList<Comp>()
        for (s in 0 until w * h) {
            if (!mask[s] || seen[s]) continue
            val c = Comp()
            var sp = 0
            stack[sp++] = s
            seen[s] = true
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                c.area++
                c.sx += x
                c.sy += y
                if (x < c.x0) c.x0 = x
                if (x > c.x1) c.x1 = x
                if (y < c.y0) c.y0 = y
                if (y > c.y1) c.y1 = y
                if (gold != null && gold[p]) c.gold++
                if (x > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; stack[sp++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; stack[sp++] = p + 1 }
                if (y > 0 && mask[p - w] && !seen[p - w]) { seen[p - w] = true; stack[sp++] = p - w }
                if (y < h - 1 && mask[p + w] && !seen[p + w]) { seen[p + w] = true; stack[sp++] = p + w }
            }
            out.add(c)
        }
        return out
    }

    private fun erode(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(w * h)
        for (y in 1 until h - 1) {
            for (x in 1 until w - 1) {
                val p = y * w + x
                o[p] = m[p] && m[p - 1] && m[p + 1] && m[p - w] && m[p + w]
            }
        }
        return o
    }

    private fun dilate(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(w * h)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val p = y * w + x
                o[p] = m[p] ||
                    (x > 0 && m[p - 1]) || (x < w - 1 && m[p + 1]) ||
                    (y > 0 && m[p - w]) || (y < h - 1 && m[p + w])
            }
        }
        return o
    }

    fun analyze(px: IntArray, w: Int, h: Int): Analysis {
        // 1) find the game area: longest run of non-black rows
        var bestLen = 0
        var bestStart = 0
        var runStart = -1
        for (y in 0..h) {
            var on = false
            if (y < h) {
                var s = 0L
                for (x in 0 until w) {
                    val p = px[y * w + x]
                    s += rr(p) + gg(p) + bb(p)
                }
                on = s / (3L * w) > 20
            }
            if (on) {
                if (runStart < 0) runStart = y
            } else if (runStart >= 0) {
                if (y - runStart > bestLen) {
                    bestLen = y - runStart
                    bestStart = runStart
                }
                runStart = -1
            }
        }
        if (bestLen < h / 4) {
            return Analysis(Screen.UNKNOWN, 0, h, 0f, 0f, -1f, -1f, -1f, emptyList())
        }
        val top = bestStart
        val hh = bestLen
        val n = w * hh

        // 2) menu: one big wide red button ("Play")
        val red = BooleanArray(n)
        var redCount = 0
        for (y in 0 until hh) {
            for (x in 0 until w) {
                val p = px[(top + y) * w + x]
                if (rr(p) > 180 && gg(p) < 90 && bb(p) < 110) {
                    red[y * w + x] = true
                    redCount++
                }
            }
        }
        if (redCount > 0.012 * n) {
            val big = components(red, w, hh, null).maxByOrNull { it.area }
            if (big != null) {
                val bw = (big.x1 - big.x0 + 1).toFloat() / w
                val bh = (big.y1 - big.y0 + 1).toFloat()
                if (bw in 0.4f..0.85f && (big.x1 - big.x0 + 1) / bh > 2.2f) {
                    return Analysis(
                        Screen.MENU, top, top + hh,
                        big.sx.toFloat() / big.area / w,
                        (big.sy.toFloat() / big.area + top) / h,
                        -1f, -1f, -1f, emptyList()
                    )
                }
            }
        }

        // 3) result screen: wide green button ("Back To Main Menu") in the lower middle
        val green = BooleanArray(n)
        var greenMid = 0
        val gy0 = (hh * 0.45f).toInt()
        val gy1 = (hh * 0.80f).toInt()
        for (y in gy0 until gy1) {
            for (x in 0 until w) {
                val p = px[(top + y) * w + x]
                if (gg(p) > 150 && rr(p) < 130 && bb(p) < 120 && gg(p) - rr(p) > 50) {
                    green[y * w + x] = true
                    greenMid++
                }
            }
        }
        if (greenMid > 0.01 * n) {
            val big = components(green, w, hh, null).maxByOrNull { it.area }
            if (big != null) {
                val bw = (big.x1 - big.x0 + 1).toFloat() / w
                val bh = (big.y1 - big.y0 + 1).toFloat()
                if (bw in 0.35f..0.85f && (big.x1 - big.x0 + 1) / bh > 2.5f) {
                    return Analysis(
                        Screen.RESULT, top, top + hh,
                        big.sx.toFloat() / big.area / w,
                        (big.sy.toFloat() / big.area + top) / h,
                        -1f, -1f, -1f, emptyList()
                    )
                }
            }
        }

        // 4) playing: green HUD bars in the top-left
        var hud = 0
        for (y in 0 until (hh * 0.25f).toInt()) {
            for (x in 0 until w / 2) {
                val p = px[(top + y) * w + x]
                if (gg(p) > 150 && rr(p) < 130) hud++
            }
        }
        if (hud <= 0.004 * n) {
            return Analysis(Screen.UNKNOWN, top, top + hh, 0f, 0f, -1f, -1f, -1f, emptyList())
        }

        return analyzeGame(px, w, h, top, hh)
    }

    private fun analyzeGame(px: IntArray, w: Int, h: Int, top: Int, hh: Int): Analysis {
        val n = w * hh
        val x0 = (w * 0.17f).toInt()
        val x1 = (w * 0.83f).toInt()

        // ground colour = two most common (coarse) colours in the lower middle
        val hist = IntArray(4096)
        for (y in (hh * 0.35f).toInt() until (hh * 0.92f).toInt()) {
            for (x in x0 until x1) {
                val p = px[(top + y) * w + x]
                hist[((rr(p) shr 4) shl 8) or ((gg(p) shr 4) shl 4) or (bb(p) shr 4)]++
            }
        }
        var k1 = 0
        for (k in 1 until 4096) if (hist[k] > hist[k1]) k1 = k
        var k2 = if (k1 == 0) 1 else 0
        for (k in 0 until 4096) if (k != k1 && hist[k] > hist[k2]) k2 = k
        val g1 = intArrayOf((k1 shr 8) * 16 + 8, ((k1 shr 4) and 15) * 16 + 8, (k1 and 15) * 16 + 8)
        val g2 = intArrayOf((k2 shr 8) * 16 + 8, ((k2 shr 4) and 15) * 16 + 8, (k2 and 15) * 16 + 8)

        val fg = BooleanArray(n)
        val binMask = BooleanArray(n)
        val gold = BooleanArray(n)
        val yTop = (hh * 0.10f).toInt()
        val yBot = (hh * 0.97f).toInt()
        for (y in yTop until yBot) {
            for (x in x0 until x1) {
                // skip HUD (top-left block, top-right sound button)
                if (y < hh * 0.30f && x < w * 0.5f) continue
                if (y < hh * 0.18f && x >= w * 0.78f) continue
                val p = px[(top + y) * w + x]
                val r = rr(p)
                val g = gg(p)
                val b = bb(p)
                val d1 = abs(r - g1[0]) + abs(g - g1[1]) + abs(b - g1[2])
                val d2 = abs(r - g2[0]) + abs(g - g2[1]) + abs(b - g2[2])
                val i = y * w + x
                if (minOf(d1, d2) > 60) fg[i] = true
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                if (b >= r + 6 && (mx - mn) < 60 && mx > 90) binMask[i] = true
                if (r > 200 && g > 140 && b < 90 && r - b > 120) gold[i] = true
            }
        }

        // the bin: biggest grey-blue blob in the lower part
        var binX = -1f
        var binY = -1f
        var binW = -1f
        var bx0 = 0
        var bx1 = 0
        var by0 = 0
        var by1 = 0
        var best = 0
        for (c in components(binMask, w, hh, null)) {
            val cy = c.sy.toFloat() / c.area
            if (c.area > best && cy > hh * 0.55f) {
                best = c.area
                binX = c.sx.toFloat() / c.area / w
                binY = cy / hh
                binW = (c.x1 - c.x0 + 1).toFloat() / w
                bx0 = c.x0; bx1 = c.x1; by0 = c.y0; by1 = c.y1
            }
        }
        if (binX >= 0f) {
            // wipe the bin (and a margin) out of the foreground
            val mw = (bx1 - bx0) / 2 + 1
            val mh = (by1 - by0) / 2 + 1
            for (y in maxOf(0, by0 - mh)..minOf(hh - 1, by1 + mh)) {
                for (x in maxOf(0, bx0 - mw)..minOf(w - 1, bx1 + mw)) fg[y * w + x] = false
            }
        }

        val clean = dilate(erode(fg, w, hh), w, hh).let { d ->
            // opening = erode then dilate; keep only what survived
            val o = BooleanArray(n)
            for (i in 0 until n) o[i] = d[i] && fg[i]
            o
        }

        val objs = ArrayList<Obj>()
        for (c in components(clean, w, hh, gold)) {
            val frac = c.area.toFloat() / n
            if (c.area < 5 || frac < 0.0009f) continue
            val kind = when {
                c.gold.toFloat() / c.area > 0.4f -> COIN
                frac < 0.0075f -> LITTER
                else -> HAZARD
            }
            objs.add(
                Obj(
                    kind,
                    c.sx.toFloat() / c.area / w,
                    c.sy.toFloat() / c.area / hh,
                    (c.x1 - c.x0 + 1).toFloat() / w,
                    (c.y1 - c.y0 + 1).toFloat() / hh
                )
            )
        }
        return Analysis(Screen.GAME, top, top + hh, 0f, 0f, binX, binY, binW, objs)
    }

    /**
     * Picks where the bin should go (as a fraction of the game width).
     * Avoids hazards above the bin, and heads for litter / coins that it can reach.
     */
    fun plan(binX: Float, binW: Float, binY: Float, objs: List<Obj>): Float {
        val minX = 0.20f
        val maxX = 0.80f
        var bestX = binX
        var bestScore = -1e9f
        var x = minX
        while (x <= maxX + 1e-4f) {
            var score = -abs(x - binX) * 2f
            for (o in objs) {
                val dy = binY - o.cy // > 0 when the object is above the bin
                if (dy < -0.06f) continue // already passed
                if (o.kind == HAZARD) {
                    val clear = o.w / 2f + binW / 2f + 0.04f
                    if (abs(o.cx - x) < clear && dy < 0.6f) {
                        val urgency = 1f - dy.coerceIn(0f, 0.6f) / 0.6f
                        score -= 50f * (0.3f + urgency)
                    }
                } else {
                    val reach = abs(o.cx - x)
                    if (reach < 0.06f && dy < 0.7f) {
                        val value = if (o.kind == COIN) 3f else 5f
                        score += value * (1f - reach / 0.06f) * (1f - dy.coerceIn(0f, 0.7f) / 1.0f)
                    }
                }
            }
            if (score > bestScore) {
                bestScore = score
                bestX = x
            }
            x += 0.02f
        }
        return bestX
    }
}
