package com.forestbot

import kotlin.math.abs
import kotlin.math.sqrt

enum class Screen { MENU, RESULT, GAME, UNKNOWN }

/**
 * Looks at one small screenshot (160 px wide) and works out
 *  - which screen the game is on (menu / result / playing / unknown)
 *  - where the bin, litter, coins and hazards (animals, stumps) are.
 *
 * Objects are found by how much they differ from the (light, pastel) ground, then told apart
 * (litter / hazard) by comparing a tiny thumbnail with sprites taken from real recordings
 * (assets/lib.bin).
 *
 * All pixels are packed as 0xRRGGBB ints. Positions of objects are fractions of the
 * game area (the part of the screen that is not black bars).
 */
object Vision {
    const val COIN = 0
    const val LITTER = 1
    const val HAZARD = 2
    private const val IGN = -1

    // How the game behaves (measured from screen recordings)
    private const val VSCROLL = 0.70f  // game-heights per second the world scrolls down
    private const val VBIN = 0.9f      // game-widths per second the bin can move
    private const val LAG = 0.25f      // seconds between our command and the bin reacting

    @JvmField var MARGIN = 0.10f
    @JvmField var NEAR = 0.05f

    private const val TH = 12
    private const val TLEN = TH * TH * 3

    private var libCls = IntArray(0)
    private var libThumb: Array<IntArray> = emptyArray()

    /** [cut] = classified as a hazard only because it was partly hidden (top edge / HUD): not yet a sure thing. */
    class Obj(val kind: Int, val cx: Float, val cy: Float, val w: Float, val h: Float, val vx: Float = 0f, val cut: Boolean = false)

    class Analysis(
        val screen: Screen,
        val top: Int,
        val bottom: Int,
        val tapX: Float,      // fraction of the full frame, for MENU / RESULT
        val tapY: Float,
        val binX: Float,      // fractions of the game area, -1 if bin not found
        val binY: Float,
        val binW: Float,
        val objs: List<Obj>,
        val binH: Float = -1f
    )

    /** Loads the sprite library (assets/lib.bin). */
    fun setLibrary(data: ByteArray) {
        val n = data[0].toInt() and 255
        val cls = IntArray(n)
        val th = Array(n) { IntArray(TLEN) }
        var p = 1
        for (i in 0 until n) {
            val c = data[p].toInt() and 255
            cls[i] = if (c == 0) IGN else c
            p++
            for (j in 0 until TLEN) th[i][j] = data[p + j].toInt() and 255
            p += TLEN
        }
        libCls = cls
        libThumb = th
    }

    private fun rr(p: Int) = (p shr 16) and 255
    private fun gg(p: Int) = (p shr 8) and 255
    private fun bb(p: Int) = p and 255

    // ---- reusable buffers (the analysis runs on one thread only) ----
    private var cap = 0
    private var fgA = BooleanArray(0)
    private var binA = BooleanArray(0)
    private var goldA = BooleanArray(0)
    private var oliveA = BooleanArray(0)
    private var dilA = BooleanArray(0)
    private var dilB = BooleanArray(0)
    private var lab = IntArray(0)
    private var stack = IntArray(0)

    private fun ensure(n: Int) {
        if (n > cap) {
            cap = n
            fgA = BooleanArray(n)
            binA = BooleanArray(n)
            goldA = BooleanArray(n)
            oliveA = BooleanArray(n)
            dilA = BooleanArray(n)
            dilB = BooleanArray(n)
            lab = IntArray(n)
            stack = IntArray(n)
        }
    }

    private class Comp {
        var area = 0
        var sx = 0L
        var sy = 0L
        var x0 = Int.MAX_VALUE
        var x1 = -1
        var y0 = Int.MAX_VALUE
        var y1 = -1
        var real = 0
        var gold = 0
    }

    /** Connected blobs of [mask]; labels are left in [lab] (1-based, in the order returned). */
    private fun label(mask: BooleanArray, w: Int, h: Int, real: BooleanArray?, gold: BooleanArray?): ArrayList<Comp> {
        val n = w * h
        java.util.Arrays.fill(lab, 0, n, 0)
        val out = ArrayList<Comp>()
        for (s in 0 until n) {
            if (!mask[s] || lab[s] != 0) continue
            val c = Comp()
            val id = out.size + 1
            var sp = 0
            stack[sp++] = s
            lab[s] = id
            while (sp > 0) {
                val p = stack[--sp]
                val x = p % w
                val y = p / w
                c.area++
                c.sx += x
                c.sy += y
                if (x < c.x0) c.x0 = x
                if (x > c.x1) c.x1 = x
                if (y < c.y0) c.y0 = y
                if (y > c.y1) c.y1 = y
                if (real != null && real[p]) c.real++
                if (gold != null && gold[p]) c.gold++
                if (x > 0 && mask[p - 1] && lab[p - 1] == 0) { lab[p - 1] = id; stack[sp++] = p - 1 }
                if (x < w - 1 && mask[p + 1] && lab[p + 1] == 0) { lab[p + 1] = id; stack[sp++] = p + 1 }
                if (y > 0 && mask[p - w] && lab[p - w] == 0) { lab[p - w] = id; stack[sp++] = p - w }
                if (y < h - 1 && mask[p + w] && lab[p + w] == 0) { lab[p + w] = id; stack[sp++] = p + w }
            }
            out.add(c)
        }
        return out
    }

    private fun dilate(src: BooleanArray, dst: BooleanArray, w: Int, h: Int) {
        for (y in 0 until h) {
            for (x in 0 until w) {
                val p = y * w + x
                dst[p] = src[p] ||
                    (x > 0 && src[p - 1]) || (x < w - 1 && src[p + 1]) ||
                    (y > 0 && src[p - w]) || (y < h - 1 && src[p + w])
            }
        }
    }

    fun analyze(px: IntArray, w: Int, h: Int): Analysis {
        ensure(w * h)

        // 1) find the game area: longest run of non-black rows
        var bestLen = 0
        var bestStart = 0
        var runStart = -1
        for (y in 0..h) {
            var on = false
            if (y < h) {
                var s = 0L
                for (x in 0 until w) {
                    val p = px[y * w + x]
                    s += rr(p) + gg(p) + bb(p)
                }
                on = s / (3L * w) > 20
            }
            if (on) {
                if (runStart < 0) runStart = y
            } else if (runStart >= 0) {
                if (y - runStart > bestLen) {
                    bestLen = y - runStart
                    bestStart = runStart
                }
                runStart = -1
            }
        }
        if (bestLen < h / 4) {
            return Analysis(Screen.UNKNOWN, 0, h, 0f, 0f, -1f, -1f, -1f, emptyList())
        }
        val top = bestStart
        val hh = bestLen
        val n = w * hh

        // 2) menu: one big wide red button ("Play")
        val red = fgA
        java.util.Arrays.fill(red, 0, n, false)
        var redCount = 0
        for (y in 0 until hh) {
            for (x in 0 until w) {
                val p = px[(top + y) * w + x]
                if (rr(p) > 180 && gg(p) < 90 && bb(p) < 110) {
                    red[y * w + x] = true
                    redCount++
                }
            }
        }
        if (redCount > 0.012 * n) {
            val big = label(red, w, hh, null, null).maxByOrNull { it.area }
            if (big != null) {
                val bw = (big.x1 - big.x0 + 1).toFloat() / w
                val bh = (big.y1 - big.y0 + 1).toFloat()
                if (bw in 0.4f..0.85f && (big.x1 - big.x0 + 1) / bh > 2.2f) {
                    return Analysis(
                        Screen.MENU, top, top + hh,
                        big.sx.toFloat() / big.area / w,
                        (big.sy.toFloat() / big.area + top) / h,
                        -1f, -1f, -1f, emptyList()
                    )
                }
            }
        }

        // 3) result screen: wide green button ("Back To Main Menu") in the lower middle
        val green = binA
        java.util.Arrays.fill(green, 0, n, false)
        var greenMid = 0
        val gy0 = (hh * 0.45f).toInt()
        val gy1 = (hh * 0.80f).toInt()
        for (y in gy0 until gy1) {
            for (x in 0 until w) {
                val p = px[(top + y) * w + x]
                if (gg(p) > 150 && rr(p) < 130 && bb(p) < 120 && gg(p) - rr(p) > 50) {
                    green[y * w + x] = true
                    greenMid++
                }
            }
        }
        if (greenMid > 0.01 * n) {
            val big = label(green, w, hh, null, null).maxByOrNull { it.area }
            if (big != null) {
                val bw = (big.x1 - big.x0 + 1).toFloat() / w
                val bh = (big.y1 - big.y0 + 1).toFloat()
                if (bw in 0.35f..0.85f && (big.x1 - big.x0 + 1) / bh > 2.5f) {
                    return Analysis(
                        Screen.RESULT, top, top + hh,
                        big.sx.toFloat() / big.area / w,
                        (big.sy.toFloat() / big.area + top) / h,
                        -1f, -1f, -1f, emptyList()
                    )
                }
            }
        }

        // 4) playing: green HUD bars in the top-left
        var hud = 0
        for (y in 0 until (hh * 0.25f).toInt()) {
            for (x in 0 until w / 2) {
                val p = px[(top + y) * w + x]
                if (gg(p) > 150 && rr(p) < 130) hud++
            }
        }
        if (hud <= 0.004 * n) {
            return Analysis(Screen.UNKNOWN, top, top + hh, 0f, 0f, -1f, -1f, -1f, emptyList())
        }

        return analyzeGame(px, w, top, hh)
    }

    private fun lumOf(p: Int) = (77 * rr(p) + 151 * gg(p) + 28 * bb(p)) shr 8

    private fun analyzeGame(px: IntArray, w: Int, top: Int, hh: Int): Analysis {
        val n = w * hh
        val x0 = (w * 0.15f).toInt()
        val x1 = (w * 0.85f).toInt()
        val yTop = (hh * 0.10f).toInt()
        val yBot = (hh * 0.97f).toInt()

        // The ground: typical brightness and "yellowness" (red minus blue) of the field.
        val histLum = IntArray(256)
        val histRb = IntArray(511)
        var count = 0
        for (y in (hh * 0.45f).toInt() until (hh * 0.92f).toInt()) {
            for (x in (w * 0.25f).toInt() until (w * 0.75f).toInt()) {
                val p = px[(top + y) * w + x]
                histLum[lumOf(p)]++
                histRb[rr(p) - bb(p) + 255]++
                count++
            }
        }
        var acc = 0
        var groundLum = 0
        for (i in 0 until 256) {
            acc += histLum[i]
            if (acc * 2 >= count) { groundLum = i; break }
        }
        acc = 0
        var groundRb = 0
        for (i in 0 until 511) {
            acc += histRb[i]
            if (acc * 2 >= count) { groundRb = i - 255; break }
        }

        java.util.Arrays.fill(fgA, 0, n, false)
        java.util.Arrays.fill(binA, 0, n, false)
        java.util.Arrays.fill(goldA, 0, n, false)
        java.util.Arrays.fill(oliveA, 0, n, false)
        for (y in yTop until yBot) {
            for (x in x0 until x1) {
                // skip HUD (top-left block, top-right sound button)
                if (y < hh * 0.32f && x < w * 0.53f) continue
                if (y < hh * 0.18f && x >= w * 0.78f) continue
                val p = px[(top + y) * w + x]
                val r = rr(p)
                val g = gg(p)
                val b = bb(p)
                val i = y * w + x
                // The bot's own overlay boxes are magenta/violet - never treat them as objects.
                if ((r + b) / 2 - g > 28 && r > 120 && b > 120) continue
                val lum = lumOf(p)
                // pastel green trees leaning into the field
                val tree = g >= r + 12 && g >= b + 12 && lum > 140
                if (!tree && (abs((r - b) - groundRb) > 38 || groundLum - lum > 65)) fgA[i] = true
                val mx = maxOf(r, maxOf(g, b))
                val mn = minOf(r, minOf(g, b))
                if (b >= r + 6 && (mx - mn) < 60 && mx > 90) binA[i] = true
                if (r > 200 && g > 140 && b < 90 && r - b > 120) goldA[i] = true
                // snakes are olive (red ~ green, blue far lower); the pink ground, brown animals, gold and teal cans are not
                if (g >= r - 6 && g > b + 35 && lum < 170) oliveA[i] = true
            }
        }

        // the bin: biggest grey-blue blob in the lower part
        var binX = -1f
        var binY = -1f
        var binW = -1f
        var binH = -1f
        var bx0 = 0
        var bx1 = 0
        var by0 = 0
        var by1 = 0
        var best = 0
        for (c in label(binA, w, hh, null, null)) {
            val cy = c.sy.toFloat() / c.area
            if (c.area > best && cy > hh * 0.55f) {
                best = c.area
                binX = c.sx.toFloat() / c.area / w
                binY = cy / hh
                binW = (c.x1 - c.x0 + 1).toFloat() / w
                binH = (c.y1 - c.y0 + 1).toFloat() / hh
                bx0 = c.x0; bx1 = c.x1; by0 = c.y0; by1 = c.y1
            }
        }
        if (binX >= 0f) {
            // wipe the bin (and a margin) out of the foreground
            val mw = (bx1 - bx0) / 2 + 1
            val mh = (by1 - by0) / 2 + 1
            for (y in maxOf(0, by0 - mh)..minOf(hh - 1, by1 + mh)) {
                for (x in maxOf(0, bx0 - mw)..minOf(w - 1, bx1 + mw)) fgA[y * w + x] = false
            }
        }

        // merge pieces of one object (stripes, outlines) by growing every blob 2 pixels
        dilate(fgA, dilA, w, hh)
        dilate(dilA, dilB, w, hh)
        val comps = label(dilB, w, hh, fgA, goldA)

        val objs = ArrayList<Obj>()
        val t = IntArray(TLEN)
        // Rows / columns where the HUD hides the field: animals sliding out from behind it look tiny
        // (and used to be called litter until they were halfway down the screen).
        val hudBot = (hh * 0.32f).toInt()
        val hudRight = (w * 0.53f).toInt()
        val btnBot = (hh * 0.18f).toInt()
        val btnLeft = (w * 0.78f).toInt()
        for ((idx, c) in comps.withIndex()) {
            val rfrac = c.real.toFloat() / n
            if (c.real < 4) continue
            if (rfrac < 0.0008f && c.gold <= 3) continue
            val kind: Int
            var cut = false
            if (c.gold.toFloat() / maxOf(1, c.real) > 0.4f) {
                kind = COIN
            } else {
                thumb(px, w, top, idx + 1, c, t)
                var k = nearest(t, rfrac)
                // snakes are thin, so the size rule calls them litter: recognise them by colour instead
                var olive = 0
                var bright = 0   // blue / cyan / red: the colours of litter (bags, cups, cans), never of an animal or stump
                val fromFallback = fallbackUsed
                for (yy in c.y0..c.y1) for (xx in c.x0..c.x1) {
                    val i = yy * w + xx
                    if (fgA[i] && lab[i] == idx + 1) {
                        if (oliveA[i]) olive++
                        val p = px[(top + yy) * w + xx]
                        val pr = rr(p); val pg = gg(p); val pb = bb(p)
                        if (pb >= pr + 30 || (pr - maxOf(pg, pb) >= 70 && pg < 120)) bright++
                    }
                }
                val litterColour = bright.toFloat() / maxOf(1, c.real) > 0.30f
                // big litter the library does not know used to be called a hazard just because it is big
                if (fromFallback && litterColour && k == HAZARD) k = LITTER
                if (olive.toFloat() / maxOf(1, c.real) > 0.30f) k = HAZARD
                if (k == IGN) continue
                // an object cut off by the top edge can't be recognised reliably: play safe
                if (c.y0 <= yTop + 1 && rfrac >= 0.006f && !litterColour) { k = HAZARD; cut = true }
                // same for something poking out from under the HUD block or the sound button
                val underHud = c.y0 <= hudBot + 2 && c.x0 < hudRight
                val underBtn = c.y0 <= btnBot + 2 && c.x1 >= btnLeft
                if ((underHud || underBtn) && rfrac >= 0.0030f && k != HAZARD && !litterColour) { k = HAZARD; cut = true }
                kind = k
            }
            objs.add(
                Obj(
                    kind,
                    c.sx.toFloat() / c.area / w,
                    c.sy.toFloat() / c.area / hh,
                    (c.x1 - c.x0 + 1).toFloat() / w,
                    (c.y1 - c.y0 + 1).toFloat() / hh,
                    0f,
                    cut
                )
            )
        }
        return Analysis(Screen.GAME, top, top + hh, 0f, 0f, binX, binY, binW, objs, binH)
    }

    /** 12x12 average-colour thumbnail of one blob (background grey), same as the library tool. */
    private fun thumb(px: IntArray, w: Int, top: Int, id: Int, c: Comp, out: IntArray) {
        val bw = c.x1 - c.x0 + 1
        val bh = c.y1 - c.y0 + 1
        for (ty in 0 until TH) {
            val ya = ty * bh / TH
            val yb = maxOf(ya + 1, ((ty + 1) * bh + TH - 1) / TH)
            for (tx in 0 until TH) {
                val xa = tx * bw / TH
                val xb = maxOf(xa + 1, ((tx + 1) * bw + TH - 1) / TH)
                var sr = 0
                var sg = 0
                var sb = 0
                var cnt = 0
                for (yy in ya until minOf(yb, bh)) {
                    for (xx in xa until minOf(xb, bw)) {
                        val xp = c.x0 + xx
                        val yp = c.y0 + yy
                        val i = yp * w + xp
                        if (fgA[i] && lab[i] == id) {
                            val p = px[(top + yp) * w + xp]
                            sr += rr(p); sg += gg(p); sb += bb(p)
                        } else {
                            sr += 128; sg += 128; sb += 128
                        }
                        cnt++
                    }
                }
                val o = (ty * TH + tx) * 3
                val d = maxOf(cnt, 1)
                out[o] = (sr + d / 2) / d
                out[o + 1] = (sg + d / 2) / d
                out[o + 2] = (sb + d / 2) / d
            }
        }
    }

    private var fallbackUsed = false

    private fun nearest(t: IntArray, rfrac: Float): Int {
        fallbackUsed = false
        var bestD = Long.MAX_VALUE
        var bestK = -1
        for (k in libThumb.indices) {
            val l = libThumb[k]
            var s = 0L
            for (j in 0 until TLEN) {
                val d = t[j] - l[j]
                s += (d * d).toLong()
            }
            if (s < bestD) {
                bestD = s
                bestK = k
            }
        }
        if (bestK >= 0) {
            val rms = sqrt(bestD.toDouble() / TLEN) / 255.0
            val c = libCls[bestK]
            if (c == HAZARD) {
                // only trust a hazard match when it is a close match and the thing is big enough
                if (rms < 0.07 && rfrac >= 0.0028f) return HAZARD
            } else if (rms < 0.10) {
                return c
            }
        }
        // not in the library: big things are hazards, small things are litter
        fallbackUsed = true
        return if (rfrac >= 0.0070f) HAZARD else LITTER
    }

    // Where would the bin be after t seconds if we send it to tx now?
    private fun simX(binX: Float, tx: Float, t: Float, speed: Float = VBIN, lag: Float = LAG): Float {
        val d = tx - binX
        val move = maxOf(0f, t - lag) * speed
        return if (abs(d) <= move) tx else binX + (if (d > 0f) move else -move)
    }

    private fun score(
        x: Float, binX: Float, binW: Float, binY: Float, binH: Float, objs: List<Obj>
    ): Float {
        val top = binY - binH / 2f
        val bottom = binY + binH / 2f
        var s = -abs(x - binX) * 0.5f - abs(x - 0.5f) * 0.3f // small moves, and a little pull to the middle
        for (o in objs) {
            if (o.kind == HAZARD) {
                val tIn = (top - (o.cy + o.h / 2f)) / VSCROLL
                val tOut = (bottom - (o.cy - o.h / 2f)) / VSCROLL
                if (tOut < -0.05f) continue
                val t0 = maxOf(tIn, 0f)
                if (t0 > 1.6f) continue
                val clear = o.w / 2f + binW / 2f + MARGIN
                var hit = false
                var near = false
                for (i in 0..8) {
                    val t = t0 + (tOut - t0) * i / 8f
                    val ox = o.cx + o.vx * maxOf(t, 0f)
                    // the bin may be slower OR faster than we think: it must be safe either way
                    val dx = minOf(
                        abs(simX(binX, x, t, 1.2f, 0.25f) - ox),
                        abs(simX(binX, x, t, 2.2f, 0.08f) - ox)
                    )
                    if (dx < clear) {
                        hit = true
                        break
                    }
                    if (dx < clear + NEAR) near = true
                }
                if (hit) s -= 100f else if (near) s -= 6f
            } else {
                val tc = (binY - o.cy) / VSCROLL
                if (tc < -0.05f || tc > 1.6f) continue
                val reach = binW / 2f + o.w / 2f - 0.01f
                if (abs(simX(binX, x, maxOf(tc, 0f), 1.6f, 0.15f) - (o.cx + o.vx * maxOf(tc, 0f))) < reach) {
                    s += (if (o.kind == COIN) 3f else 5f) / (1f + tc)
                }
            }
        }
        return s
    }

    /**
     * Picks where the bin should go (fraction of the game width): somewhere it can reach in time
     * that dodges every hazard and, if possible, catches litter and coins on the way.
     * [prev] is the previous target (or -1); it is kept unless something clearly better exists.
     */
    @JvmField var YPAD = 0.16f        // keep dodging until a hazard is this far past the bin row (v3.8 runs ended threading the trailing edge with zero slack)
    @JvmField var PLAN_SPEED = 1.0f   // bin speed (game-widths per second) the planner counts on
    @JvmField var PLAN_LAG = 0.2f     // seconds before a new command shows up as movement (measured: ~0.15 s phone + ~0.05 s vision)
    @JvmField var LOOK = 3
    @JvmField var WALL = 0f            // how many 0.1 s steps ahead the returned target is

    private const val NS = 16        // planning steps of 0.1 s
    private const val X0 = 0.22f
    private const val DX = 0.02f
    private const val NC = 30        // cells: 0.22 .. 0.80 (where the bin can really go, measured)

    /**
     * Looks ahead 1.6 s and finds the best sequence of moves (dodge hazards, grab loot),
     * then returns where the bin should be about 0.3 s from now (fraction of the game width).
     */
    fun plan(
        binX: Float, binW: Float, binY: Float, binH: Float, objs: List<Obj>, prev: Float
    ): Float {
        val dt = 0.1f
        val reward = Array(NS + 1) { FloatArray(NC) }
        for (k in 1..NS) {
            val tt = k * dt
            for (o in objs) {
                val cy = o.cy + VSCROLL * tt
                val cx = o.cx + o.vx * tt
                if (o.kind == HAZARD) {
                    if (abs(cy - binY) > (o.h + binH) / 2f + YPAD) continue
                    val clear = o.w / 2f + binW / 2f + MARGIN
                    val c0 = maxOf(0, ((cx - clear - X0) / DX).toInt())
                    val c1 = minOf(NC - 1, ((cx + clear - X0) / DX).toInt() + 1)
                    for (c in c0..c1) {
                        val x = X0 + c * DX
                        val d = abs(x - cx)
                        if (d < clear) reward[k][c] -= 100f
                        else if (d < clear + NEAR) reward[k][c] -= 4f
                    }
                } else {
                    if (abs(cy - binY) > (o.h + binH) * 0.4f) continue
                    val reach = binW / 2f + o.w / 2f - 0.01f
                    val v = (if (o.kind == COIN) 5f else 10f) / (1f + tt) / 1.6f
                    val c0 = maxOf(0, ((cx - reach - X0) / DX).toInt())
                    val c1 = minOf(NC - 1, ((cx + reach - X0) / DX).toInt() + 1)
                    for (c in c0..c1) {
                        if (abs(X0 + c * DX - cx) < reach) reward[k][c] += v
                    }
                }
            }
        }
        // staying near the walls is risky (hazards can trap us there): small cost, growing outward
        for (k in 1..NS) for (c in 0 until NC) {
            val x = X0 + c * DX
            val e = minOf(x - 0.26f, 0.82f - x)
            if (e < 0.14f) reward[k][c] -= WALL * (0.14f - e) / 0.14f
        }
        val mv = maxOf(1, (PLAN_SPEED * dt / DX).toInt())
        val lagSteps = (PLAN_LAG / dt + 0.5f).toInt()
        val start = ((binX - X0) / DX + 0.5f).toInt().coerceIn(0, NC - 1)
        // pass 1: the best plan may wait until the last moment (waiting is free).
        var path = bestPath(reward, start, mv, lagSteps, -1, 0f)
        var dest = start
        var moved = false
        for (k in 1..NS) {
            if (path[k] != path[k - 1]) moved = true
            else if (moved) break
            dest = path[k]
        }
        // pass 2: same plan, but prefer to be at the destination early (safer, no last-second sprint)
        if (dest != start) path = bestPath(reward, start, mv, lagSteps, dest, 0.006f)

        // Hysteresis: the old code ignored [prev], so the target flipped between neighbouring
        // loot every frame and the bin never committed to any of them. Keep heading for the
        // previous target unless a different plan is clearly better.
        if (prev >= 0f) {
            val pc = ((prev - X0) / DX + 0.5f).toInt().coerceIn(0, NC - 1)
            if (pc != dest) {
                val keep = bestPath(reward, start, mv, lagSteps, pc, 0.5f)
                if (pathValue(reward, keep) >= pathValue(reward, path) - HYST) path = keep
            }
        }
        // Return where the plan ends its first move (not the 0.3 s waypoint). The old waypoint was
        // always only ~0.1 from the lagging bin, so the bin crept toward safety and got hit.
        var d = path[0]
        var mvd = false
        for (k in 1..NS) {
            if (path[k] != path[k - 1]) mvd = true
            else if (mvd) break
            d = path[k]
        }
        return X0 + d * DX
    }

    private const val HYST = 1.0f

    private fun pathValue(reward: Array<FloatArray>, path: IntArray): Float {
        var s = 0f
        for (k in 1..NS) {
            s += reward[k][path[k]] - 0.04f * abs(path[k] - path[k - 1]) - 0.02f * abs(X0 + path[k] * DX - 0.5f)
        }
        return s
    }

    private fun bestPath(reward: Array<FloatArray>, start: Int, mv: Int, lagSteps: Int, dest: Int, pull: Float): IntArray {
        val value = Array(NS + 1) { FloatArray(NC) }
        for (k in NS - 1 downTo 0) {
            val lim = if (k < lagSteps) 0 else mv
            for (i in 0 until NC) {
                var best = -1e9f
                for (j in maxOf(0, i - lim)..minOf(NC - 1, i + lim)) {
                    var sc = value[k + 1][j] + reward[k + 1][j] - 0.04f * abs(j - i) - 0.02f * abs(X0 + j * DX - 0.5f)
                    if (dest >= 0) sc -= pull * abs(j - dest)
                    if (sc > best) best = sc
                }
                value[k][i] = best
            }
        }
        val path = IntArray(NS + 1)
        path[0] = start
        var cell = start
        for (k in 0 until NS) {
            val lim = if (k < lagSteps) 0 else mv
            var best = -1e9f
            var bj = cell
            for (j in maxOf(0, cell - lim)..minOf(NC - 1, cell + lim)) {
                var sc = value[k + 1][j] + reward[k + 1][j] - 0.04f * abs(j - cell) - 0.02f * abs(X0 + j * DX - 0.5f)
                if (dest >= 0) sc -= pull * abs(j - dest)
                if (sc > best + 1e-4f) { best = sc; bj = j }
            }
            cell = bj
            path[k + 1] = cell
        }
        return path
    }
}
