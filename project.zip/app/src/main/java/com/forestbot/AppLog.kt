package com.forestbot

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Small text log so we can see why the bot stopped. */
object AppLog {
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun init(ctx: Context) {
        file = File(ctx.filesDir, "log.txt")
    }

    @Synchronized
    fun add(msg: String) {
        try {
            val f = file ?: return
            if (f.length() > 20000) {
                val keep = f.readText().takeLast(8000)
                f.writeText(keep)
            }
            f.appendText(fmt.format(Date()) + " " + msg + "\n")
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun tail(ctx: Context, n: Int): String {
        return try {
            val f = File(ctx.filesDir, "log.txt")
            if (!f.exists()) "" else f.readLines().takeLast(n).joinToString("\n")
        } catch (_: Exception) {
            ""
        }
    }
}
