package com.forestbot

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** The Google AI Studio keys the person pasted in the app, in the order they are tried. */
object AiKeys {
    const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
    private const val PREFS = "oxy"

    fun keys(ctx: Context): List<String> = try {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("ai_keys", "")!!
            .split('\n').map { it.trim() }.filter { it.isNotEmpty() }
    } catch (_: Exception) { emptyList() }

    private fun save(ctx: Context, list: List<String>) {
        try { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("ai_keys", list.joinToString("\n")).apply() } catch (_: Exception) {}
    }

    fun add(ctx: Context, key: String): Boolean {
        val k = key.trim().replace("\n", "").replace(" ", "")
        if (k.length < 20) return false
        val l = keys(ctx)
        if (k in l) return false
        save(ctx, l + k)
        return true
    }

    fun remove(ctx: Context, index: Int) {
        val l = keys(ctx).toMutableList()
        if (index in l.indices) { l.removeAt(index); save(ctx, l) }
    }

    fun moveUp(ctx: Context, index: Int) {
        val l = keys(ctx).toMutableList()
        if (index in 1 until l.size) { val k = l.removeAt(index); l.add(index - 1, k); save(ctx, l) }
    }

    fun model(ctx: Context): String = try {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("ai_model", DEFAULT_MODEL)!!.ifBlank { DEFAULT_MODEL }
    } catch (_: Exception) { DEFAULT_MODEL }

    fun setModel(ctx: Context, m: String) {
        try { ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("ai_model", m.trim()).apply() } catch (_: Exception) {}
    }
}

/** What the AI decided about an unknown screen. */
class Decision(val screen: String, val desc: String, val action: String, val x: Float, val y: Float, val reason: String)

/** Asks Google Gemini what to do on a screen the bot does not know. Tries each key in order. */
object Gemini {
    @Volatile var status = "AI helper: not used yet"
    @Volatile var calls = 0
    private val coolUntil = HashMap<String, Long>()

    private const val SYSTEM = """You help an Android bot that plays a mobile game automatically. The bot does not recognise the current screen. It could be an advertisement, a pop-up, a reward offer, a loading or glitch screen, or the game itself.
You get up to 3 screenshots taken about 2 seconds apart, oldest first. The LAST one is the current screen. You also get the actions the bot already tried.
Decide ONE next action. Answer with JSON only:
{"screen":"ad|popup|offer|loading|glitch|game|menu|other","desc":"what you see, 12 words max","action":"tap|back|relaunch|wait","x":0.0,"y":0.0,"reason":"short"}
x and y are fractions of the screen width and height (0..1) measured from the top-left of the LAST screenshot; they are only used for tap.
Rules:
- The bot WANTS to watch ads to the end (a finished rewarded ad gives a 4x reward). Never skip an ad that is still running, and never press back on one. Some ads are several ads in a row: after one ends, wait for the next. A close button (X) often appears only after the ad is over, sometimes after a countdown, and sometimes there is none and the ad closes itself.
- A dark dimmed screen with 'Ad Break' or a spinner means an ad is loading: action wait.
- A video or ad that is still playing, or has a countdown: action wait. Tap a close button (X, 'Close', 'Continue', 'Claim') only when it is clearly visible and the ad is finished; 'Skip' only if the ad has been playing for a long time without finishing.
- Close buttons are usually small and in a top corner; look carefully. Never tap 'Install', 'Download', 'Learn more', 'Open', 'Buy', 'Subscribe', or the ad picture itself.
- Never tap anything in the bottom 10% of the screen (banner ads live there), and never tap a button that spends real money.
- If the ad opened a browser or the Play Store: back. If the screen looks frozen, broken or completely black for many frames in a row (more than about 20 seconds): relaunch.
- If a previous action did not change the screen, try something different. If nothing works after several tries, use relaunch.
- If the screenshot is really the game or its normal menu, set screen to game or menu and action wait.
"""

    private fun ready(key: String, now: Long) = (coolUntil[key] ?: 0L) <= now

    /** Returns the decision, or null when no key worked (the reason is in [status]). */
    fun ask(ctx: Context, jpegs: List<ByteArray>, tried: List<String>): Decision? {
        val keys = AiKeys.keys(ctx)
        if (keys.isEmpty()) { status = "AI helper: no key set"; return null }
        val model = AiKeys.model(ctx)
        val body = JSONObject()
        body.put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYSTEM))))
        val parts = JSONArray()
        val hist = if (tried.isEmpty()) "No action tried yet." else "Actions already tried (oldest first): " + tried.joinToString(" | ")
        parts.put(JSONObject().put("text", "$hist\nScreenshots follow, oldest first; the last one is now."))
        for (j in jpegs) parts.put(JSONObject().put("inlineData", JSONObject()
            .put("mimeType", "image/jpeg").put("data", Base64.encodeToString(j, Base64.NO_WRAP))))
        body.put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
        body.put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 1024)
            .put("responseMimeType", "application/json"))
        val payload = body.toString().toByteArray()

        var lastErr = ""
        val now0 = System.currentTimeMillis()
        for ((i, key) in keys.withIndex()) {
            val now = System.currentTimeMillis()
            if (!ready(key, now)) { lastErr = "key ${i + 1} resting"; continue }
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 8000
                c.readTimeout = 30000
                c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(payload) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                calls++
                if (code in 200..299) {
                    val d = parse(txt)
                    if (d != null) {
                        status = "AI helper OK (key ${i + 1}): ${d.desc} -> ${d.action}"
                        return d
                    }
                    lastErr = "key ${i + 1}: unreadable answer"
                    continue
                }
                lastErr = "key ${i + 1}: HTTP $code"
                when (code) {
                    429 -> coolUntil[key] = System.currentTimeMillis() + 15 * 60_000L      // limit reached
                    400, 401, 403 -> coolUntil[key] = System.currentTimeMillis() + 60 * 60_000L // bad key
                    404 -> { status = "AI helper: model '$model' not found (change it in the app)"; return null }
                    else -> coolUntil[key] = System.currentTimeMillis() + 30_000L
                }
                AppLog.add("AI $lastErr, trying the next key")
            } catch (e: Exception) {
                lastErr = "key ${i + 1}: ${e.javaClass.simpleName}"
                coolUntil[key] = System.currentTimeMillis() + 20_000L
            }
        }
        status = "AI helper failed ($lastErr)"
        return null
    }

    private fun parse(txt: String): Decision? = try {
        val t = JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        val s = t.indexOf('{'); val e = t.lastIndexOf('}')
        val j = JSONObject(t.substring(s, e + 1))
        Decision(j.optString("screen", "other"), j.optString("desc", ""), j.optString("action", "wait").lowercase(),
            j.optDouble("x", -1.0).toFloat(), j.optDouble("y", -1.0).toFloat(), j.optString("reason", ""))
    } catch (_: Exception) { null }

    /** One tiny text request per key, so the person can see which keys work. */
    fun test(ctx: Context): String {
        val keys = AiKeys.keys(ctx)
        if (keys.isEmpty()) return "No key set."
        val model = AiKeys.model(ctx)
        val sb = StringBuilder("Model: $model\n")
        val payload = JSONObject().put("contents", JSONArray().put(JSONObject().put("role", "user")
            .put("parts", JSONArray().put(JSONObject().put("text", "Reply with the single word OK."))))).toString().toByteArray()
        for ((i, key) in keys.withIndex()) {
            try {
                val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
                    .openConnection() as HttpURLConnection
                c.requestMethod = "POST"; c.connectTimeout = 8000; c.readTimeout = 20000; c.doOutput = true
                c.setRequestProperty("Content-Type", "application/json")
                c.setRequestProperty("x-goog-api-key", key)
                c.outputStream.use { it.write(payload) }
                val code = c.responseCode
                val txt = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText() ?: ""
                c.disconnect()
                if (code in 200..299) {
                    val ans = try {
                        JSONObject(txt).getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
                            .getJSONArray("parts").getJSONObject(0).getString("text").trim()
                    } catch (_: Exception) { "?" }
                    sb.append("Key ${i + 1} (••••${key.takeLast(4)}): works - answered \"$ans\"\n")
                } else {
                    val msg = try { JSONObject(txt).getJSONObject("error").getString("message").take(140) } catch (_: Exception) { txt.take(140) }
                    sb.append("Key ${i + 1} (••••${key.takeLast(4)}): FAILED HTTP $code - $msg\n")
                }
            } catch (e: Exception) {
                sb.append("Key ${i + 1} (••••${key.takeLast(4)}): FAILED - ${e.javaClass.simpleName}: ${e.message}\n")
            }
        }
        return sb.toString().trim()
    }
}
