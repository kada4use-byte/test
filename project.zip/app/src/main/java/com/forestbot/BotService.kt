package com.forestbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlin.math.abs

/**
 * Watches the screen (small screenshots) and plays the game through the accessibility service.
 */
class BotService : Service() {

    companion object {
        @Volatile
        var running = false

        @Volatile
        var status = "Not running"

        const val AW = 160          // analysis width in pixels
        const val GAIN = 1.0f       // how far to drag per unit the bin must move
        private const val CHANNEL = "forestbot"
        private const val ACTION_STOP = "com.forestbot.STOP"
        private const val ACTION_SAVE = "com.forestbot.SAVE"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var worker: Thread? = null

    @Volatile
    private var stopFlag = false

    @Volatile
    private var saveRequested = false

    private var sw = 1080
    private var sh = 2400
    private var ah = 355

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SAVE -> {
                saveRequested = true
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        startAsForeground()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        sw = minOf(dm.widthPixels, dm.heightPixels)
        sh = maxOf(dm.widthPixels, dm.heightPixels)
        ah = (AW.toLong() * sh / sw).toInt()

        val r = ImageReader.newInstance(AW, ah, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "forestbot", AW, ah, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )

        running = true
        stopFlag = false
        worker = Thread { loop() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Forest Bot", NotificationManager.IMPORTANCE_LOW)
        )
        fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, BotService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Forest Bot is running")
            .setContentText("Pull down and tap Stop to end it")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "Stop", pi(ACTION_STOP, 1))
            .addAction(android.R.drawable.ic_menu_camera, "Save frame", pi(ACTION_SAVE, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        stopFlag = true
        running = false
        status = "Stopped"
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun toPixels(img: Image): IntArray {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val ps = pl.pixelStride
        val out = IntArray(AW * ah)
        for (y in 0 until ah) {
            var idx = y * rs
            for (x in 0 until AW) {
                val r = buf.get(idx).toInt() and 255
                val g = buf.get(idx + 1).toInt() and 255
                val b = buf.get(idx + 2).toInt() and 255
                out[y * AW + x] = (r shl 16) or (g shl 8) or b
                idx += ps
            }
        }
        return out
    }

    private fun loop() {
        var lastBinX = 0.5f
        var lastTap = 0L
        var unknownSince = 0L
        var lastAttempt = 0L
        var attempts = 0
        var savedUnknown = 0

        while (!stopFlag) {
            val img = try { reader?.acquireLatestImage() } catch (_: Exception) { null }
            if (img == null) {
                Thread.sleep(30)
                continue
            }
            val px = try {
                toPixels(img)
            } finally {
                img.close()
            }

            val svc = GameAccessibilityService.instance
            val a = Vision.analyze(px, AW, ah)
            val now = System.currentTimeMillis()
            val hazards = a.objs.count { it.kind == Vision.HAZARD }
            val loot = a.objs.size - hazards
            status = "Screen: ${a.screen}  bin=${"%.2f".format(a.binX)}  loot=$loot  hazards=$hazards"

            if (saveRequested) {
                saveRequested = false
                saveDebug(px, a, "manual")
            }

            if (svc == null) {
                status = "Accessibility is OFF - turn it on in Settings"
                Thread.sleep(500)
                continue
            }

            when (a.screen) {
                Screen.MENU, Screen.RESULT -> {
                    unknownSince = 0
                    attempts = 0
                    if (now - lastTap > 2500) {
                        svc.tap(a.tapX * sw, a.tapY * sh)
                        lastTap = now
                    }
                    Thread.sleep(100)
                }
                Screen.GAME -> {
                    unknownSince = 0
                    attempts = 0
                    val hh = a.bottom - a.top
                    val bx = if (a.binX >= 0f) a.binX else lastBinX
                    lastBinX = bx
                    val by = if (a.binY >= 0f) a.binY else 0.8f
                    val bw = if (a.binW > 0f) a.binW else 0.15f
                    val target = Vision.plan(bx, bw, by, a.objs)
                    if (abs(target - bx) > 0.02f) {
                        val y = (a.top + by * hh) / ah.toFloat() * sh
                        val x2 = (bx + (target - bx) * GAIN).coerceIn(0.05f, 0.95f) * sw
                        svc.swipe(bx * sw, y, x2, y, (40 + 150 * abs(target - bx)).toLong())
                    } else {
                        Thread.sleep(30)
                    }
                }
                Screen.UNKNOWN -> {
                    if (unknownSince == 0L) unknownSince = now
                    val waited = now - unknownSince
                    if (waited > 6000 && savedUnknown < 5 && attempts == 0) {
                        saveDebug(px, a, "unknown")
                        savedUnknown++
                    }
                    // Probably an ad or a pop-up: try to close it.
                    if (waited > 6000 && now - lastAttempt > 2500) {
                        when (attempts % 4) {
                            0 -> svc.tap(0.93f * sw, 0.06f * sh)
                            1 -> svc.tap(0.07f * sw, 0.06f * sh)
                            2 -> svc.back()
                            3 -> svc.tap(0.5f * sw, 0.9f * sh)
                        }
                        attempts++
                        lastAttempt = now
                    }
                    Thread.sleep(150)
                }
            }
        }
    }

    private fun saveDebug(px: IntArray, a: Vision.Analysis, tag: String) {
        try {
            val argb = IntArray(px.size) { px[it] or (0xFF shl 24) }
            val small = Bitmap.createBitmap(argb, AW, ah, Bitmap.Config.ARGB_8888)
            val bmp = Bitmap.createScaledBitmap(small, AW * 3, ah * 3, false).copy(Bitmap.Config.ARGB_8888, true)
            val c = Canvas(bmp)
            val p = Paint()
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f
            p.textSize = 28f
            val hh = a.bottom - a.top
            p.color = Color.MAGENTA
            c.drawText("${a.screen}", 8f, 30f, p)
            for (o in a.objs) {
                p.color = when (o.kind) {
                    Vision.COIN -> Color.YELLOW
                    Vision.LITTER -> Color.GREEN
                    else -> Color.RED
                }
                val cx = o.cx * AW * 3
                val cy = (a.top + o.cy * hh) * 3
                c.drawRect(cx - o.w * AW * 1.5f, cy - o.h * hh * 1.5f, cx + o.w * AW * 1.5f, cy + o.h * hh * 1.5f, p)
            }
            if (a.binX >= 0f) {
                p.color = Color.BLUE
                val cx = a.binX * AW * 3
                val cy = (a.top + a.binY * hh) * 3
                c.drawRect(cx - a.binW * AW * 1.5f, cy - 40f, cx + a.binW * AW * 1.5f, cy + 40f, p)
            }
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "forestbot_${tag}_${System.currentTimeMillis()}.png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ForestBot")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
        }
    }
}
