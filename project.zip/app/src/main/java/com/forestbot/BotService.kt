package com.forestbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.provider.Settings
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import kotlin.math.abs

/**
 * Watches the screen (small screenshots) and plays the game through the accessibility service.
 */
class BotService : Service() {

    companion object {
        @Volatile
        var running = false

        @Volatile
        var status = "Not running"

        @Volatile
        var paused = false

        const val AW = 160          // analysis width in pixels
        const val KP = 0.7f         // how hard the finger chases the target
        const val KD = 0.35f        // damping so the bin does not overshoot
        const val DEAD = 0.025f      // do not move for smaller errors (stops the shaking)
        private const val CHANNEL = "forestbot"
        private const val ACTION_STOP = "com.forestbot.STOP"
        private const val ACTION_SAVE = "com.forestbot.SAVE"
    }

    private var projection: MediaProjection? = null
    @Volatile
    private var display: VirtualDisplay? = null

    @Volatile
    private var reader: ImageReader? = null

    @Volatile
    private var worker: Thread? = null

    @Volatile
    private var control: Thread? = null

    @Volatile
    private var lastFrame = 0L

    @Volatile
    private var inGame = false

    @Volatile
    private var lastErr = ""

    private var wasAcc = true
    private var restarts = 0

    private class Cmd(val seq: Long, val time: Long, val binX: Float, val target: Float, val binVel: Float)

    @Volatile
    private var cmd: Cmd? = null
    private var overlay: BoxOverlay? = null
    private var bar: android.widget.LinearLayout? = null
    private val main = Handler(Looper.getMainLooper())

    @Volatile
    private var stopFlag = false

    @Volatile
    private var saveRequested = false

    private var sw = 1080
    private var sh = 2400
    private var ah = 355

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_SAVE -> {
                saveRequested = true
                return START_NOT_STICKY
            }
        }
        if (running) return START_NOT_STICKY

        val code = intent?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = intent?.getParcelableExtra("data")
        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        AppLog.init(this)
        AppLog.add("--- OxyDoxy v3.1 started ---")
        startAsForeground()

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        if (proj == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                AppLog.add("projection stopped by system")
                stopSelf()
            }
        }, main)

        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(dm)
        sw = minOf(dm.widthPixels, dm.heightPixels)
        sh = maxOf(dm.widthPixels, dm.heightPixels)
        ah = (AW.toLong() * sh / sw).toInt()

        val r = ImageReader.newInstance(AW, ah, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "forestbot", AW, ah, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )

        paused = false
        addOverlay()
        addBar()

        // sprite library used to tell litter from hazards
        try {
            val lib = assets.open("lib.bin").use { it.readBytes() }
            Vision.setLibrary(lib)
        } catch (_: Exception) {
        }

        running = true
        stopFlag = false
        lastFrame = System.currentTimeMillis()
        worker = Thread { loop() }.also { it.start() }
        control = Thread { controlLoop() }.also { it.start() }
        main.postDelayed(watchdog, 1000)
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "OxyDoxy", NotificationManager.IMPORTANCE_LOW)
        )
        fun pi(action: String, code: Int): PendingIntent = PendingIntent.getService(
            this, code, Intent(this, BotService::class.java).setAction(action),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        @Suppress("DEPRECATION")
        val n: Notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("OxyDoxy is running")
            .setContentText("Pull down and tap Stop to end it")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(android.R.drawable.ic_delete, "Stop", pi(ACTION_STOP, 1))
            .addAction(android.R.drawable.ic_menu_camera, "Save frame", pi(ACTION_SAVE, 2))
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        main.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val v = BoxOverlay(this)
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.START
                if (Build.VERSION.SDK_INT >= 28) {
                    lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
                wm.addView(v, lp)
                overlay = v
            } catch (_: Exception) {
            }
        }
    }

    private fun addBar() {
        if (!Settings.canDrawOverlays(this)) return
        main.post {
            try {
                val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val row = android.widget.LinearLayout(this)
                row.orientation = android.widget.LinearLayout.HORIZONTAL
                fun btn(label: String, onClick: (android.widget.Button) -> Unit): android.widget.Button {
                    val b = android.widget.Button(this)
                    b.text = label
                    b.setTextColor(Color.BLACK)
                    b.setBackgroundColor(Color.rgb(230, 80, 230))
                    b.textSize = 13f
                    b.setPadding(24, 0, 24, 0)
                    b.minHeight = 0
                    b.minimumHeight = 0
                    b.setOnClickListener { onClick(b) }
                    val lp = android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 90
                    )
                    lp.setMargins(8, 0, 8, 0)
                    row.addView(b, lp)
                    return b
                }
                btn("PAUSE") { b ->
                    paused = !paused
                    b.text = if (paused) "RESUME" else "PAUSE"
                    AppLog.add(if (paused) "paused by button" else "resumed by button")
                }
                btn("STOP") {
                    AppLog.add("stopped by button")
                    startService(Intent(this, BotService::class.java).setAction(ACTION_STOP))
                }
                val lp = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                )
                lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                lp.y = 4
                wm.addView(row, lp)
                bar = row
            } catch (e: Exception) {
                AppLog.add("button bar failed " + e)
            }
        }
    }

    private fun removeBar() {
        val v = bar ?: return
        bar = null
        main.post {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    private fun removeOverlay() {
        val v = overlay ?: return
        overlay = null
        main.post {
            try {
                (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
            } catch (_: Exception) {
            }
        }
    }

    private val watchdog = object : Runnable {
        override fun run() {
            if (stopFlag) return
            try { check() } catch (e: Exception) { AppLog.add("watchdog error " + e) }
            main.postDelayed(this, 1000)
        }
    }

    private fun check() {
        val now = System.currentTimeMillis()
        if (worker?.isAlive != true) {
            AppLog.add("vision thread died - restarting")
            worker = Thread { loop() }.also { it.start() }
        }
        if (control?.isAlive != true) {
            AppLog.add("control thread died - restarting")
            control = Thread { controlLoop() }.also { it.start() }
        }
        val acc = GameAccessibilityService.instance != null
        if (acc != wasAcc) {
            AppLog.add(if (acc) "accessibility back ON" else "accessibility turned OFF by phone")
            wasAcc = acc
        }
        if (now - lastFrame > 2500 && restarts < 20) {
            restarts++
            AppLog.add("no screen frames for 2.5s - rebuilding capture (#" + restarts + ")")
            try {
                val old = reader
                val r = ImageReader.newInstance(AW, ah, PixelFormat.RGBA_8888, 2)
                display?.setSurface(r.surface)
                reader = r
                try { old?.close() } catch (_: Exception) {}
            } catch (e: Exception) {
                AppLog.add("rebuild failed " + e)
            }
            lastFrame = now
        }
        if (lastErr.isNotEmpty()) {
            AppLog.add("error: " + lastErr)
            lastErr = ""
        }
    }

    override fun onDestroy() {
        AppLog.add("service destroyed")
        main.removeCallbacks(watchdog)
        stopFlag = true
        running = false
        status = "Stopped"
        try { GameAccessibilityService.instance?.release() } catch (_: Exception) {}
        removeOverlay()
        removeBar()
        try { display?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun toPixels(img: Image): IntArray {
        val pl = img.planes[0]
        val buf = pl.buffer
        val rs = pl.rowStride
        val ps = pl.pixelStride
        val out = IntArray(AW * ah)
        for (y in 0 until ah) {
            var idx = y * rs
            for (x in 0 until AW) {
                val r = buf.get(idx).toInt() and 255
                val g = buf.get(idx + 1).toInt() and 255
                val b = buf.get(idx + 2).toInt() and 255
                out[y * AW + x] = (r shl 16) or (g shl 8) or b
                idx += ps
            }
        }
        return out
    }

    private fun buildOverlay(a: Vision.Analysis, objs: List<Vision.Obj>, target: Float, title: String): BoxOverlay.Data {
        val hh = a.bottom - a.top
        val boxes = ArrayList<BoxOverlay.Box>()
        for (o in objs) {
            if (o.cy > 0.97f) continue
            val cx = o.cx * sw
            val cy = (a.top + o.cy * hh) / ah.toFloat() * sh
            val hw = o.w * sw / 2f + 8f
            val hy = o.h * hh / ah.toFloat() * sh / 2f + 8f
            val kind: Int
            val label: String
            when (o.kind) {
                Vision.HAZARD -> { kind = BoxOverlay.K_HAZARD; label = "DANGER" }
                Vision.COIN -> { kind = BoxOverlay.K_COIN; label = "COIN" }
                else -> { kind = BoxOverlay.K_LITTER; label = "LOOT" }
            }
            boxes.add(BoxOverlay.Box(cx - hw, cy - hy, cx + hw, cy + hy, kind, label))
        }
        var lineBottom = 0f
        if (a.binX >= 0f) {
            val cx = a.binX * sw
            val cy = (a.top + a.binY * hh) / ah.toFloat() * sh
            val hw = maxOf(a.binW, 0.1f) * sw / 2f + 8f
            val hy = maxOf(a.binH, 0.08f) * hh / ah.toFloat() * sh / 2f + 8f
            lineBottom = cy - hy
        }
        val lineTop = (a.top + 0.12f * hh) / ah.toFloat() * sh
        return BoxOverlay.Data(boxes, if (target >= 0f) target * sw else -1f, lineTop, lineBottom, title)
    }

    private var menuSince = 0L
    private var menuHandled = false

    /**
     * On the home screen: reads the numbers and buys upgrades, keeping bin size about
     * distance/10 + up to 5 (250 -> 30 bins, then 300, ...). Only taps when we have enough coins.
     */
    private fun doUpgrades(svc: GameAccessibilityService) {
        var unreadable = 0
        var noChange = 0
        var lastCoins = -1
        var lastStat = -1
        var lastWasTrash = false
        for (step in 0 until 16) {
            if (stopFlag || paused) return
            lastFrame = System.currentTimeMillis()
            val shot = svc.screenshot()
            if (shot == null) {
                AppLog.add("upgrade: screenshot not possible (switch Accessibility off and on once)")
                return
            }
            val m = MenuReader.read(shot.px, shot.w, shot.h)
            AppLog.add("menu: $m")
            if (m.dist < 0 || m.cap < 0 || m.coins < 0) {
                unreadable++
                if (unreadable >= 2) { AppLog.add("upgrade: cannot read the numbers"); return }
                Thread.sleep(600)
                continue
            }
            if (lastCoins >= 0) {
                val stat = if (lastWasTrash) m.cap else m.dist
                if (m.coins == lastCoins && stat == lastStat) {
                    noChange++
                    if (noChange >= 2) { AppLog.add("upgrade: tap did nothing, stopping"); return }
                } else {
                    noChange = 0
                }
            }
            var wantTrash = m.cap < m.dist / 10 + 5
            var cost = if (wantTrash) m.costT else m.costD
            var name = if (wantTrash) "bin size" else "distance"
            if (cost <= 0) { AppLog.add("upgrade: cannot read price of $name"); return }
            if (m.coins < cost) {
                // The stat we want is too expensive right now. Don't sit on the coins: buy the other
                // one if we can afford it and that keeps the two roughly level.
                val otherCost = if (wantTrash) m.costD else m.costT
                val otherOk = otherCost > 0 && m.coins >= otherCost &&
                    (if (wantTrash) m.cap >= m.dist / 10 + 1 else m.cap < m.dist / 10 + 12)
                if (!otherOk) {
                    AppLog.add("upgrade: $name costs $cost, you have ${m.coins} - waiting")
                    return
                }
                wantTrash = !wantTrash
                cost = otherCost
                name = if (wantTrash) "bin size" else "distance"
                AppLog.add("upgrade: cheaper path - buying $name instead")
            }
            lastCoins = m.coins
            lastStat = if (wantTrash) m.cap else m.dist
            lastWasTrash = wantTrash
            AppLog.add("upgrade: buying $name for $cost")
            val bx = (if (wantTrash) MenuReader.BTN_TRASH_X else MenuReader.BTN_DIST_X) * shot.w
            svc.tap(bx, MenuReader.BTN_Y * shot.h)
            Thread.sleep(1100)
        }
    }

    private var frames = 0
    private var fpsT = 0L
    private var fps = 0f

    private fun loop() {
        var lastBinX = 0.5f
        var lastGameT = 0L
        var prevTarget = -1f
        var binVel = 0f
        var seq = 0L
        var lastTap = 0L
        var unknownSince = 0L
        var lastAttempt = 0L
        var attempts = 0
        var savedUnknown = 0
        var lastScreen: Screen? = null

        while (!stopFlag) {
          try {
            val img = try { reader?.acquireLatestImage() } catch (_: Exception) { null }
            if (img == null) {
                Thread.sleep(8)
                continue
            }
            lastFrame = System.currentTimeMillis()
            val px = try {
                toPixels(img)
            } finally {
                img.close()
            }

            val svc = GameAccessibilityService.instance
            val a = Vision.analyze(px, AW, ah)
            val now = System.currentTimeMillis()
            val hazards = a.objs.count { it.kind == Vision.HAZARD }
            val loot = a.objs.size - hazards
            frames++
            if (now - fpsT > 2000) {
                fps = frames * 1000f / (now - fpsT)
                frames = 0
                fpsT = now
                if (a.screen == Screen.GAME) AppLog.add("vision %.1f fps".format(fps))
            }
            status = "Screen: ${a.screen}  ${"%.0f".format(fps)} fps  bin=${"%.2f".format(a.binX)}  loot=$loot  hazards=$hazards"

            if (saveRequested) {
                saveRequested = false
                saveDebug(px, a, "manual")
            }

            if (svc == null) {
                status = "Accessibility is OFF - turn it on in Settings"
                Thread.sleep(500)
                continue
            }

            if (paused) {
                cmd = null
                Tracker.reset()
                overlay?.update(BoxOverlay.Data(emptyList(), -1f, 0f, 0f, "PAUSED"))
                Thread.sleep(100)
                continue
            }
            if (a.screen != lastScreen) {
                AppLog.add("screen " + lastScreen + " -> " + a.screen)
                lastScreen = a.screen
            }
            inGame = a.screen == Screen.GAME
            if (a.screen != Screen.MENU) { menuSince = 0L; menuHandled = false }
            if (a.screen != Screen.GAME) {
                Tracker.reset()
                overlay?.update(null)
                cmd = null
                prevTarget = -1f
                lastGameT = 0L
                binVel = 0f
            }

            when (a.screen) {
                Screen.MENU, Screen.RESULT -> {
                    unknownSince = 0
                    attempts = 0
                    if (a.screen == Screen.MENU) {
                        if (menuSince == 0L) menuSince = now
                        if (!menuHandled && now - menuSince > 1000) {
                            try { doUpgrades(svc) } catch (e: Exception) { AppLog.add("upgrade error " + e) }
                            menuHandled = true
                            lastFrame = System.currentTimeMillis()
                        }
                    } else {
                        menuSince = 0L
                        menuHandled = false
                    }
                    val ready = a.screen == Screen.RESULT || menuHandled
                    if (ready && now - lastTap > 1200) {
                        svc.tap(a.tapX * sw, a.tapY * sh)
                        lastTap = now
                    }
                    Thread.sleep(100)
                }
                Screen.GAME -> {
                    unknownSince = 0
                    attempts = 0
                    val hh = a.bottom - a.top
                    val bx = if (a.binX >= 0f) a.binX else lastBinX
                    val by = if (a.binY >= 0f) a.binY else 0.8f
                    val bw = if (a.binW > 0f) a.binW else 0.15f
                    val bh = if (a.binH > 0f) a.binH else 0.11f

                    val dt = if (lastGameT == 0L) 0.05f else ((now - lastGameT).coerceIn(10L, 300L)) / 1000f
                    val rawVel = if (lastGameT == 0L) 0f else (bx - lastBinX) / dt
                    binVel = 0.5f * binVel + 0.5f * rawVel
                    lastGameT = now
                    lastBinX = bx

                    val tracked = Tracker.update(a.objs, dt)
                    val target = Vision.plan(bx, bw, by, bh, tracked, prevTarget)
                    prevTarget = target
                    seq++
                    cmd = Cmd(seq, now, bx, target, binVel)

                    overlay?.update(buildOverlay(a, tracked, target, "BOT  loot=$loot  danger=$hazards"))
                }
                Screen.UNKNOWN -> {
                    if (unknownSince == 0L) unknownSince = now
                    val waited = now - unknownSince
                    if (waited > 6000 && savedUnknown < 5 && attempts == 0) {
                        saveDebug(px, a, "unknown")
                        savedUnknown++
                    }
                    // Probably an ad or a pop-up: try to close it.
                    if (waited > 6000 && now - lastAttempt > 2500) {
                        when (attempts % 4) {
                            0 -> svc.tap(0.93f * sw, 0.06f * sh)
                            1 -> svc.tap(0.07f * sw, 0.06f * sh)
                            2 -> svc.back()
                            3 -> svc.tap(0.5f * sw, 0.9f * sh)
                        }
                        attempts++
                        lastAttempt = now
                    }
                    Thread.sleep(150)
                }
            }
          } catch (e: InterruptedException) {
            return
          } catch (e: Throwable) {
            lastErr = "vision: " + e
            try { Thread.sleep(50) } catch (_: Exception) {}
          }
        }
    }

    /** Moves the finger. Runs on its own thread so that thinking never waits for the finger. */
    private fun controlLoop() {
        var fx = 0.5f
        var lastSeq = -1L
        while (!stopFlag) {
          try {
            val svc = GameAccessibilityService.instance
            val c = cmd
            if (svc == null || c == null || System.currentTimeMillis() - c.time > 500) {
                if (svc != null && svc.fingerDown) svc.release()
                Thread.sleep(15)
                continue
            }
            val y = 0.60f * sh
            if (!svc.fingerDown) fx = c.binX
            if (c.seq != lastSeq) {
                lastSeq = c.seq
                val err = c.target - c.binX
                val gain = if (abs(err) > 0.08f) 1.0f else KP
                var step = gain * err - KD * c.binVel * 0.10f
                if (abs(err) < DEAD) step = 0f
                step = step.coerceIn(-0.40f, 0.40f)
                var next = fx + step
                if ((next < 0.04f || next > 0.96f) && abs(err) > 0.05f && svc.fingerDown) {
                    // finger ran out of screen: lift and put it back on the bin
                    svc.release()
                    fx = c.binX
                    next = fx + step
                }
                next = next.coerceIn(0.04f, 0.96f)
                svc.drag(next * sw, y, 45, fx * sw)
                fx = next
            } else {
                svc.drag(fx * sw, y, 45, fx * sw)
            }
          } catch (e: InterruptedException) {
            return
          } catch (e: Throwable) {
            lastErr = "control: " + e
            try { Thread.sleep(30) } catch (_: Exception) {}
          }
        }
    }

    private fun saveDebug(px: IntArray, a: Vision.Analysis, tag: String) {
        try {
            val argb = IntArray(px.size) { px[it] or (0xFF shl 24) }
            val small = Bitmap.createBitmap(argb, AW, ah, Bitmap.Config.ARGB_8888)
            val bmp = Bitmap.createScaledBitmap(small, AW * 3, ah * 3, false).copy(Bitmap.Config.ARGB_8888, true)
            val c = Canvas(bmp)
            val p = Paint()
            p.style = Paint.Style.STROKE
            p.strokeWidth = 2f
            p.textSize = 28f
            val hh = a.bottom - a.top
            p.color = Color.MAGENTA
            c.drawText("${a.screen}", 8f, 30f, p)
            for (o in a.objs) {
                p.color = when (o.kind) {
                    Vision.COIN -> Color.YELLOW
                    Vision.LITTER -> Color.GREEN
                    else -> Color.RED
                }
                val cx = o.cx * AW * 3
                val cy = (a.top + o.cy * hh) * 3
                c.drawRect(cx - o.w * AW * 1.5f, cy - o.h * hh * 1.5f, cx + o.w * AW * 1.5f, cy + o.h * hh * 1.5f, p)
            }
            if (a.binX >= 0f) {
                p.color = Color.BLUE
                val cx = a.binX * AW * 3
                val cy = (a.top + a.binY * hh) * 3
                c.drawRect(cx - a.binW * AW * 1.5f, cy - 40f, cx + a.binW * AW * 1.5f, cy + 40f, p)
            }
            val v = ContentValues()
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "forestbot_${tag}_${System.currentTimeMillis()}.png")
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= 29) {
                v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ForestBot")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v) ?: return
            contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
        } catch (_: Exception) {
        }
    }
}
