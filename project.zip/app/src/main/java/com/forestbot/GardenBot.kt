package com.forestbot

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.os.SystemClock
import java.io.ByteArrayOutputStream
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.Deflater
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Plays "Garden Fill" (muskloftsoft).
 *
 * The game: a grid with a start dot. Cells with a flower are blocked. One finger swipe from the
 * dot must pass through EVERY other cell exactly once. So: read the grid from a screenshot, solve
 * it (a Hamiltonian path search), and draw the whole solution in one swipe.
 *
 * It needs no MediaProjection: it uses the accessibility service's screenshots (Android 11+), one
 * per decision, because this game is turn based.
 */
class GardenBot(private val svc: GameAccessibilityService, private val ctx: Context, private val pkg: String) {

    companion object {
        @Volatile var running = false
        @Volatile var paused = false
        @Volatile var status = ""
        @Volatile private var current: GardenBot? = null

        const val SCALE = 4              // screenshots are analysed at 1/4 size
        const val SOLVE_MS = 4000L       // give up on one puzzle after this long
        const val MAX_SAVED_UNKNOWN = 40 // pictures of unknown screens (ads) we keep for later

        fun totalSolved(ctx: Context): Int = try {
            ctx.getSharedPreferences("oxy", Context.MODE_PRIVATE).getInt("garden_total", 0)
        } catch (_: Exception) { 0 }

        fun start(svc: GameAccessibilityService, ctx: Context, pkg: String) {
            if (running) return
            val b = GardenBot(svc, ctx.applicationContext, pkg)
            current = b
            b.begin()
        }

        fun stop() {
            current?.halt()
        }
    }

    private enum class Kind { LEVEL, COMPLETE, HOME, MODE, LIST, UNKNOWN }

    private class Board(val rows: Int, val cols: Int, val cell: Array<CharArray>, val cx: FloatArray, val cy: FloatArray)

    @Volatile private var stopFlag = false
    private var thread: Thread? = null

    // statistics
    private var solved = 0
    private var failed = 0
    private var solveMsTotal = 0L
    private var startedAt = 0L

    // recording of what happened (pictures of levels / unknown screens + a csv)
    private var zip: ZipOutputStream? = null
    private var zipOut: java.io.OutputStream? = null
    private var zipFile: File? = null
    private var zipEntries = 0
    private val csv = StringBuilder("t_s,event,detail\n")
    private var savedUnknown = 0
    private val version = RunRecorder.versionName(ctx)

    private fun begin() {
        running = true
        paused = false
        stopFlag = false
        solved = 0
        failed = 0
        startedAt = SystemClock.elapsedRealtime()
        status = "Garden Fill: starting"
        AppLog.init(ctx)
        AppLog.add("--- Garden Fill bot v$version started ---")
        svc.showBar(
            onPause = { paused = !paused; status = if (paused) "Garden Fill: paused" else "Garden Fill: resumed" ; paused },
            onStop = { halt() }
        )
        thread = Thread { loop() }.also { it.start() }
    }

    fun halt() {
        stopFlag = true
        running = false
        status = ""
        svc.hideBar()
        try { thread?.interrupt() } catch (_: Exception) {}
        AppLog.add("Garden Fill stopped: $solved solved, $failed failed")
    }

    // ------------------------------------------------------------------ screenshot helpers

    private class Pic(val w: Int, val h: Int, val r: IntArray, val g: IntArray, val b: IntArray, val fullW: Int, val fullH: Int)

    private fun shoot(): Pic? {
        val s = svc.screenshot() ?: return null
        val sw = s.w / SCALE
        val sh = s.h / SCALE
        val r = IntArray(sw * sh)
        val g = IntArray(sw * sh)
        val b = IntArray(sw * sh)
        for (y in 0 until sh) {
            val row = y * SCALE * s.w
            for (x in 0 until sw) {
                val p = s.px[row + x * SCALE]
                val i = y * sw + x
                r[i] = (p shr 16) and 255
                g[i] = (p shr 8) and 255
                b[i] = p and 255
            }
        }
        lastShot = s
        return Pic(sw, sh, r, g, b, s.w, s.h)
    }

    private var lastShot: GameAccessibilityService.Shot? = null

    private fun near(p: Pic, i: Int, cr: Int, cg: Int, cb: Int, t: Int) =
        abs(p.r[i] - cr) + abs(p.g[i] - cg) + abs(p.b[i] - cb) < t

    private fun isTileBlue(p: Pic, i: Int) = p.b[i] > 215 && p.g[i] in 110..190 && p.r[i] < 100

    /** Fraction of pixels in the box (fractions of the screen) for which [f] is true. */
    private fun frac(p: Pic, x0: Float, y0: Float, x1: Float, y1: Float, f: (Int) -> Boolean): Float {
        val ax = (x0 * p.w).toInt().coerceIn(0, p.w - 1)
        val bx = (x1 * p.w).toInt().coerceIn(ax + 1, p.w)
        val ay = (y0 * p.h).toInt().coerceIn(0, p.h - 1)
        val by = (y1 * p.h).toInt().coerceIn(ay + 1, p.h)
        var n = 0
        var t = 0
        for (y in ay until by) for (x in ax until bx) {
            t++
            if (f(y * p.w + x)) n++
        }
        return if (t == 0) 0f else n.toFloat() / t
    }

    // ------------------------------------------------------------------ board reading

    private fun parseBoard(p: Pic): Board? {
        val n = p.w * p.h
        val isBg = BooleanArray(n)
        val isBrd = BooleanArray(n)
        val pur = BooleanArray(n)
        val grn = BooleanArray(n)
        val wht = BooleanArray(n)
        for (i in 0 until n) {
            val r = p.r[i]; val g = p.g[i]; val b = p.b[i]
            val bg = abs(r - 107) + abs(g - 58) + abs(b - 10) < 40
            val cell = abs(r - 139) + abs(g - 83) + abs(b) < 40
            pur[i] = r > 150 && b > 150 && g < 120
            grn[i] = g > 110 && r < 60 && b < 90
            wht[i] = r > 225 && g > 225 && b > 225
            isBg[i] = bg
            isBrd[i] = bg || cell || pur[i] || grn[i]
        }
        // the board = the biggest block of rows / columns that are mostly board colours
        fun longestRun(len: Int, ok: (Int) -> Boolean): IntArray? {
            var bestS = -1; var bestL = 0; var s = -1
            for (i in 0..len) {
                val good = i < len && ok(i)
                if (good && s < 0) s = i
                if (!good && s >= 0) {
                    if (i - s > bestL) { bestL = i - s; bestS = s }
                    s = -1
                }
            }
            return if (bestS < 0) null else intArrayOf(bestS, bestS + bestL - 1)
        }
        val ry = longestRun(p.h) { y ->
            var c = 0
            for (x in 0 until p.w) if (isBrd[y * p.w + x]) c++
            c > p.w * 0.6f
        } ?: return null
        val y0 = ry[0]; val y1 = ry[1]
        if (y1 - y0 < p.h * 0.1f) return null
        val rx = longestRun(p.w) { x ->
            var c = 0
            for (y in y0..y1) if (isBrd[y * p.w + x]) c++
            c > (y1 - y0 + 1) * 0.6f
        } ?: return null
        val x0 = rx[0]; val x1 = rx[1]
        if (x1 - x0 < p.w * 0.3f) return null

        fun runs(len: Int, ok: (Int) -> Boolean, minLen: Int): List<IntArray> {
            val out = ArrayList<IntArray>()
            var s = -1
            for (i in 0..len) {
                val good = i < len && ok(i)
                if (good && s < 0) s = i
                if (!good && s >= 0) {
                    if (i - s >= minLen) out.add(intArrayOf(s, i - 1))
                    s = -1
                }
            }
            return out
        }
        val minC = max(4, ((x1 - x0) * 0.04f).toInt())
        val minR = max(4, ((y1 - y0) * 0.04f).toInt())
        val colRuns = runs(x1 - x0 + 1, { k ->
            val x = x0 + k
            var c = 0
            for (y in y0..y1) if (!isBg[y * p.w + x]) c++
            c > (y1 - y0 + 1) * 0.5f
        }, minC)
        val rowRuns = runs(y1 - y0 + 1, { k ->
            val y = y0 + k
            var c = 0
            for (x in x0..x1) if (!isBg[y * p.w + x]) c++
            c > (x1 - x0 + 1) * 0.5f
        }, minR)
        if (colRuns.size < 2 || rowRuns.size < 2 || colRuns.size > 24 || rowRuns.size > 24) return null

        val rows = rowRuns.size
        val cols = colRuns.size
        val cell = Array(rows) { CharArray(cols) }
        val cx = FloatArray(cols)
        val cy = FloatArray(rows)
        var starts = 0
        for (ri in 0 until rows) {
            val ya = y0 + rowRuns[ri][0]; val yb = y0 + rowRuns[ri][1]
            cy[ri] = ((ya + yb) / 2f + 0.5f) * SCALE * p.fullH / (p.h * SCALE).toFloat()
            for (ci in 0 until cols) {
                val xa = x0 + colRuns[ci][0]; val xb = x0 + colRuns[ci][1]
                if (ri == 0) cx[ci] = ((xa + xb) / 2f + 0.5f) * SCALE * p.fullW / (p.w * SCALE).toFloat()
                val mx = (xa + xb) / 2; val my = (ya + yb) / 2
                val hw = max(1, (xb - xa) / 4); val hh = max(1, (yb - ya) / 4)
                var np = 0; var ng = 0; var nw = 0; var t = 0
                for (y in my - hh..my + hh) for (x in mx - hw..mx + hw) {
                    if (x < 0 || y < 0 || x >= p.w || y >= p.h) continue
                    val i = y * p.w + x
                    t++
                    if (pur[i]) np++
                    if (grn[i]) ng++
                    if (wht[i]) nw++
                }
                val tt = max(1, t).toFloat()
                cell[ri][ci] = when {
                    np / tt > 0.12f -> 'F'
                    ng / tt > 0.10f || nw / tt > 0.05f -> { starts++; 'S' }
                    else -> '.'
                }
            }
        }
        if (starts != 1) return null   // a half-drawn path (or something that is not a fresh board)
        return Board(rows, cols, cell, cx, cy)
    }

    // ------------------------------------------------------------------ the solver

    /** Returns the cells (row*cols+col) in drawing order, or null if no path fills the board. */
    private fun solve(bd: Board): IntArray? {
        val R = bd.rows
        val C = bd.cols
        val free = BooleanArray(R * C) { bd.cell[it / C][it % C] != 'F' }
        var start = -1
        for (i in 0 until R * C) if (bd.cell[i / C][i % C] == 'S') start = i
        if (start < 0) return null
        var total = 0
        for (i in 0 until R * C) if (free[i]) total++
        val vis = BooleanArray(R * C)
        val path = IntArray(total)
        var len = 0
        path[len++] = start
        vis[start] = true
        val dr = intArrayOf(0, 1, 0, -1)
        val dc = intArrayOf(1, 0, -1, 0)
        val deadline = SystemClock.elapsedRealtime() + SOLVE_MS
        var nodes = 0L
        val seen = IntArray(R * C)
        var stamp = 0
        val stack = IntArray(R * C)

        fun neighbours(i: Int, out: IntArray): Int {
            var k = 0
            val r = i / C; val c = i % C
            for (d in 0 until 4) {
                val rr = r + dr[d]; val cc = c + dc[d]
                if (rr < 0 || cc < 0 || rr >= R || cc >= C) continue
                val j = rr * C + cc
                if (free[j] && !vis[j]) out[k++] = j
            }
            return k
        }

        val tmp = IntArray(4)
        fun degree(i: Int): Int = neighbours(i, tmp)

        // The cells left must all be reachable from the head, and at most one of them may be a dead end
        // (that one is where the path will finish).
        fun feasible(): Boolean {
            val head = path[len - 1]
            stamp++
            var sp = 0
            stack[sp++] = head
            seen[head] = stamp
            var count = 0
            var dead = 0
            val nb = IntArray(4)
            while (sp > 0) {
                val cur = stack[--sp]
                val k = neighbours(cur, nb)
                if (cur != head) {
                    count++
                    var deg = k
                    val hr = head / C; val hc = head % C
                    if (abs(cur / C - hr) + abs(cur % C - hc) == 1) deg++
                    if (deg <= 1) dead++
                }
                for (q in 0 until k) {
                    val j = nb[q]
                    if (seen[j] != stamp) { seen[j] = stamp; stack[sp++] = j }
                }
            }
            return count == total - len && dead <= 1
        }

        fun dfs(): Boolean {
            nodes++
            if ((nodes and 1023L) == 0L && SystemClock.elapsedRealtime() > deadline) return false
            if (len == total) return true
            val head = path[len - 1]
            val cand = IntArray(4)
            val k = neighbours(head, cand)
            // fewest onward moves first (Warnsdorff)
            val deg = IntArray(k)
            for (q in 0 until k) {
                vis[cand[q]] = true
                deg[q] = degree(cand[q])
                vis[cand[q]] = false
            }
            for (a in 1 until k) {
                var b = a
                while (b > 0 && deg[b - 1] > deg[b]) {
                    val t1 = deg[b]; deg[b] = deg[b - 1]; deg[b - 1] = t1
                    val t2 = cand[b]; cand[b] = cand[b - 1]; cand[b - 1] = t2
                    b--
                }
            }
            for (q in 0 until k) {
                val j = cand[q]
                vis[j] = true
                path[len++] = j
                if (feasible() && dfs()) return true
                len--
                vis[j] = false
                if (SystemClock.elapsedRealtime() > deadline) return false
            }
            return false
        }
        return if (dfs()) path.copyOf(len) else null
    }

    // ------------------------------------------------------------------ screen kinds

    private fun classify(p: Pic): Kind {
        // a fresh or half-drawn board: lots of board brown
        val brown = frac(p, 0f, 0.2f, 1f, 0.8f) { near(p, it, 107, 58, 10, 40) || near(p, it, 139, 83, 0, 40) }
        if (brown > 0.35f) return Kind.LEVEL
        val blue = frac(p, 0f, 0f, 1f, 1f) { isTileBlue(p, it) }
        if (blue > 0.40f) return Kind.COMPLETE
        // mode picker: a blue pill and a green pill under it
        val pill = frac(p, 0.30f, 0.24f, 0.70f, 0.275f) { near(p, it, 45, 147, 229, 60) }
        val green = frac(p, 0.30f, 0.36f, 0.70f, 0.39f) { near(p, it, 108, 192, 37, 70) }
        if (pill > 0.5f && green > 0.5f) return Kind.MODE
        // level list: blue tiles in the top-left
        val tile = frac(p, 0.12f, 0.15f, 0.24f, 0.21f) { isTileBlue(p, it) }
        if (tile > 0.5f) return Kind.LIST
        // home: the big blue Play circle in the middle
        val play = frac(p, 0.40f, 0.46f, 0.60f, 0.54f) { near(p, it, 44, 147, 233, 70) }
        if (play > 0.35f) return Kind.HOME
        return Kind.UNKNOWN
    }

    // ------------------------------------------------------------------ actions

    private fun fx(p: Pic, x: Float) = x * p.fullW
    private fun fy(p: Pic, y: Float) = y * p.fullH

    private fun tapFrac(p: Pic, x: Float, y: Float) {
        svc.tap(fx(p, x), fy(p, y))
    }

    private fun sleep(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) { stopFlag = true }
    }

    /** Taps the middle of the biggest green blob in the lower part of the picture (the "Next" button). */
    private fun tapNext(p: Pic): Boolean {
        var sx = 0L; var sy = 0L; var n = 0
        for (y in (p.h * 0.45f).toInt() until p.h) for (x in 0 until p.w) {
            val i = y * p.w + x
            if (p.g[i] > 170 && p.r[i] in 60..150 && p.b[i] < 125) { sx += x; sy += y; n++ }
        }
        if (n < 60) return false
        svc.tap((sx.toFloat() / n + 0.5f) * SCALE * p.fullW / (p.w * SCALE).toFloat(),
            (sy.toFloat() / n + 0.5f) * SCALE * p.fullH / (p.h * SCALE).toFloat())
        return true
    }

    /** In the level list: scroll until the white tile (the level we are on) is visible, then tap it. */
    private fun pickCurrentLevel(first: Pic): Boolean {
        var p: Pic? = first
        for (attempt in 0 until 10) {
            val pic = p ?: return false
            val colsX = floatArrayOf(0.18f, 0.39f, 0.60f, 0.81f)
            var y = 0.12f
            while (y < 0.72f) {
                for (cxf in colsX) {
                    val white = frac(pic, cxf - 0.05f, y - 0.012f, cxf + 0.05f, y + 0.012f) {
                        pic.r[it] > 242 && pic.g[it] > 242 && pic.b[it] > 242
                    }
                    if (white > 0.85f) {
                        tapFrac(pic, cxf, y)
                        log("list", "tapped white tile at ${"%.2f".format(cxf)},${"%.2f".format(y)}")
                        return true
                    }
                }
                y += 0.015f
            }
            // not visible: scroll the list up
            svc.swipe(floatArrayOf(pic.fullW * 0.5f, pic.fullW * 0.5f), floatArrayOf(pic.fullH * 0.62f, pic.fullH * 0.28f), 450)
            sleep(700)
            p = shoot()
        }
        return false
    }

    // ------------------------------------------------------------------ main loop

    private fun loop() {
        val guard = AdGuard(svc, ctx, pkg)
        var savedThis = 0
        var lastKind = Kind.UNKNOWN
        var homeTries = 0
        var levelFails = 0
        var lastLevelSig = ""
        try {
            while (!stopFlag) {
                if (paused) { sleep(300); continue }
                val p = shoot()
                if (p == null) {
                    status = "Garden Fill: cannot take screenshots (needs Android 11+ and Accessibility)"
                    sleep(1500)
                    continue
                }
                val kind = classify(p)
                if (kind != lastKind) log("screen", kind.name)
                lastKind = kind
                if (kind != Kind.UNKNOWN) { guard.reset(); savedThis = 0 }
                when (kind) {
                    Kind.LEVEL -> {
                        homeTries = 0
                        val bd = parseBoard(p)
                        if (bd == null) {
                            // half drawn: press restart (bottom middle) and look again
                            // either half drawn, or a finished level waiting for the "Level Complete" screen:
                            // give it a moment, and only then press restart
                            sleep(1500)
                            val p2 = shoot()
                            if (p2 != null && classify(p2) == Kind.LEVEL && parseBoard(p2) == null) {
                                status = "Garden Fill: resetting the level"
                                tapFrac(p2, 0.5f, 0.805f)
                                sleep(900)
                            }
                            continue
                        }
                        val sig = bd.rows.toString() + "x" + bd.cols + ":" + bd.cell.joinToString("") { String(it) }
                        if (sig == lastLevelSig) levelFails++ else { levelFails = 0; lastLevelSig = sig }
                        status = "Garden Fill: solving ${bd.rows}x${bd.cols}  (done $solved)"
                        val t0 = SystemClock.elapsedRealtime()
                        val path = solve(bd)
                        val ms = SystemClock.elapsedRealtime() - t0
                        if (path == null) {
                            failed++
                            log("nosolution", "${bd.rows}x${bd.cols} ${ms}ms")
                            saveShot("nosol_$failed")
                            tapFrac(p, 0.5f, 0.805f)
                            sleep(1200)
                            continue
                        }
                        val xs = FloatArray(path.size) { bd.cx[path[it] % bd.cols] }
                        val ys = FloatArray(path.size) { bd.cy[path[it] / bd.cols] }
                        // slower on every repeated try of the same level
                        val per = 55L + 45L * min(levelFails, 3)
                        val dur = max(500L, path.size * per)
                        saveShot("lvl_${solved + failed + 1}")
                        svc.swipe(xs, ys, dur)
                        log("swipe", "${bd.rows}x${bd.cols} cells=${path.size} solve=${ms}ms dur=${dur}ms try=${levelFails + 1}")
                        // the "Level Complete" screen takes a moment to appear: look for up to 4 s
                        var done = false
                        for (k in 0 until 10) {
                            sleep(400)
                            val after = shoot()
                            if (after != null && classify(after) != Kind.LEVEL) { done = true; break }
                        }
                        if (done) {
                            solved++
                            try { ctx.getSharedPreferences("oxy", Context.MODE_PRIVATE).edit().putInt("garden_total", totalSolved(ctx) + 1).apply() } catch (_: Exception) {}
                            solveMsTotal += ms
                            levelFails = 0
                            lastLevelSig = ""
                        } else if (levelFails >= 2) {
                            // stuck on this level: ask for a fresh start
                            failed++
                            saveShot("stuck_$failed")
                            tapFrac(p, 0.5f, 0.805f)
                            sleep(1000)
                        } else {
                            tapFrac(p, 0.5f, 0.805f)
                            sleep(800)
                        }
                    }
                    Kind.COMPLETE -> {
                        status = "Garden Fill: level complete (done $solved)"
                        if (!tapNext(p)) tapFrac(p, 0.5f, 0.70f)
                        sleep(1500)
                    }
                    Kind.HOME -> {
                        status = "Garden Fill: opening the game"
                        homeTries++
                        tapFrac(p, 0.5f, 0.50f)
                        sleep(1500)
                    }
                    Kind.MODE -> {
                        status = "Garden Fill: choosing Beginner"
                        tapFrac(p, 0.5f, 0.257f)
                        sleep(1500)
                    }
                    Kind.LIST -> {
                        status = "Garden Fill: choosing the level"
                        if (!pickCurrentLevel(p)) {
                            log("list", "no white tile found")
                            svc.tap(p.fullW * 0.18f, p.fullH * 0.18f)
                        }
                        sleep(1500)
                    }
                    Kind.UNKNOWN -> {
                        val now = SystemClock.elapsedRealtime()
                        val waited = guard.step(now, p.fullW.toFloat(), p.fullH.toFloat())
                        status = "Garden Fill: ad / unknown screen (${waited / 1000}s)"
                        if (waited > 3500 && savedUnknown < MAX_SAVED_UNKNOWN && waited / 4000 >= savedThis) {
                            saveShot("unknown_${savedUnknown}")
                            savedUnknown++
                            savedThis++
                        }
                        sleep(900)
                    }
                }
            }
        } catch (e: InterruptedException) {
        } catch (e: Throwable) {
            AppLog.add("Garden Fill crashed: $e")
            status = "Garden Fill stopped: $e"
        } finally {
            closeZip()
            running = false
            svc.hideBar()
        }
    }

    // ------------------------------------------------------------------ recording (pictures + csv, exported like Forest Cleaner runs)

    private fun log(event: String, detail: String) {
        val t = (SystemClock.elapsedRealtime() - startedAt) / 1000.0
        synchronized(csv) { csv.append("%.1f".format(Locale.US, t)).append(',').append(event).append(',').append(detail.replace(',', ';')).append('\n') }
        AppLog.add("garden $event $detail")
    }

    private fun openZip() {
        if (zip != null) return
        try {
            val dir = RunRecorder.runsDir(ctx)
            dir.mkdirs()
            if (dir.usableSpace < 300L * 1024 * 1024) return
            val name = "garden_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + "_v" + version.replace(".", "")
            val f = File(dir, "$name.zip")
            zipFile = f
            val os = f.outputStream()
            zipOut = os
            val z = ZipOutputStream(os.buffered(128 * 1024))
            z.setLevel(Deflater.NO_COMPRESSION)
            zip = z
            zipEntries = 0
        } catch (e: Exception) {
            AppLog.add("garden zip: $e")
        }
    }

    /** Saves the last screenshot (small) into the garden zip. */
    private fun saveShot(tag: String) {
        try {
            val s = lastShot ?: return
            openZip()
            val z = zip ?: return
            val w = 360
            val h = (w.toLong() * s.h / s.w).toInt()
            // pixels are stored as 0xRRGGBB (no alpha), so force them opaque
            val opaque = Bitmap.createBitmap(s.w, s.h, Bitmap.Config.ARGB_8888)
            val px = IntArray(s.w * s.h)
            for (i in px.indices) px[i] = s.px[i] or (0xFF shl 24)
            opaque.setPixels(px, 0, s.w, 0, 0, s.w, s.h)
            val sm = Bitmap.createScaledBitmap(opaque, w, h, true)
            val jpg = ByteArrayOutputStream(60 * 1024)
            sm.compress(Bitmap.CompressFormat.JPEG, 60, jpg)
            sm.recycle()
            opaque.recycle()
            z.putNextEntry(ZipEntry("$tag.jpg"))
            jpg.writeTo(z)
            z.closeEntry()
            zipEntries++
            if (zipEntries >= 60) closeZip()   // keep every file small and always complete
        } catch (e: Throwable) {
            AppLog.add("garden save: $e")
        }
    }

    private fun closeZip() {
        val z = zip ?: return
        try {
            z.putNextEntry(ZipEntry("events.csv"))
            synchronized(csv) { z.write(csv.toString().toByteArray()) }
            z.closeEntry()
            z.putNextEntry(ZipEntry("info.txt"))
            z.write(("game=Garden Fill\nversion=$version\nsolved=$solved\nfailed=$failed\n" +
                "avg_solve_ms=${if (solved > 0) solveMsTotal / solved else 0}\n").toByteArray())
            z.closeEntry()
            z.close()
        } catch (e: Exception) {
            AppLog.add("garden zip close: $e")
        }
        try { zipOut?.close() } catch (_: Exception) {}
        zip = null
        zipOut = null
        synchronized(csv) { csv.setLength(0); csv.append("t_s,event,detail\n") }
        try { RunRecorder.prune(ctx) } catch (_: Exception) {}
    }
}
