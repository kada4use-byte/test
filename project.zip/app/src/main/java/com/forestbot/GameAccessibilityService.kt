package com.forestbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.graphics.PixelFormat
import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Does the actual tapping and swiping for the bot. */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GameAccessibilityService? = null
    }

    // The finger that is currently held on the screen (a continuing stroke), if any.
    private var stroke: GestureDescription.StrokeDescription? = null
    private var fingerX = 0f
    private var fingerY = 0f
    private var nudge = 0.5f

    class Shot(val px: IntArray, val w: Int, val h: Int)

    /** Takes a full-size screenshot (Android 11+). Returns null if the phone refuses. */
    fun screenshot(): Shot? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var shot: Shot? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        if (bmp != null) {
                            val soft = bmp.copy(Bitmap.Config.ARGB_8888, false)
                            val px = IntArray(soft.width * soft.height)
                            soft.getPixels(px, 0, soft.width, 0, 0, soft.width, soft.height)
                            for (i in px.indices) px[i] = px[i] and 0xFFFFFF
                            shot = Shot(px, soft.width, soft.height)
                            soft.recycle()
                        }
                        hb.close()
                    } catch (e: Exception) {
                        AppLog.add("screenshot error " + e)
                    }
                    latch.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    AppLog.add("screenshot refused, code " + errorCode)
                    latch.countDown()
                }
            })
            latch.await(4, TimeUnit.SECONDS)
        } catch (e: Exception) {
            AppLog.add("screenshot error " + e)
        }
        return shot
    }

    val fingerDown: Boolean
        @Synchronized get() = stroke != null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Keeps one finger down and slides it to (toX, y). Starts the touch at startX if none is down. */
    @Synchronized
    fun drag(toX: Float, y: Float, durationMs: Long, startX: Float): Boolean {
        try {
            val s = stroke
            val sx = if (s != null) fingerX else startX
            val sy = if (s != null) fingerY else y
            var ex = toX
            if (ex == sx && y == sy) {
                nudge = -nudge
                ex += nudge
            }
            val path = Path()
            path.moveTo(sx, sy)
            path.lineTo(ex, y)
            val desc = if (s == null) {
                GestureDescription.StrokeDescription(path, 0, durationMs, true)
            } else {
                s.continueStroke(path, 0, durationMs, true)
            }
            val ok = dispatchAndWait(desc, durationMs)
            if (ok) {
                stroke = desc
                fingerX = ex
                fingerY = y
            } else {
                stroke = null
            }
            return ok
        } catch (e: Exception) {
            stroke = null
            return false
        }
    }

    /** Lifts the finger. */
    @Synchronized
    fun release() {
        val s = stroke ?: return
        stroke = null
        try {
            val path = Path()
            path.moveTo(fingerX, fingerY)
            path.lineTo(fingerX + 0.5f, fingerY)
            dispatchAndWait(s.continueStroke(path, 0, 10, false), 10)
        } catch (e: Exception) {
        }
    }

    // ---- Garden Fill helpers -------------------------------------------------------------

    /** Draws one continuous stroke through the given points (screen pixels) in [durationMs]. */
    @Synchronized
    fun swipe(xs: FloatArray, ys: FloatArray, durationMs: Long): Boolean {
        release()
        if (xs.isEmpty() || xs.size != ys.size) return false
        return try {
            val path = Path()
            path.moveTo(xs[0], ys[0])
            if (xs.size == 1) path.lineTo(xs[0] + 0.5f, ys[0])
            for (i in 1 until xs.size) path.lineTo(xs[i], ys[i])
            dispatchAndWait(GestureDescription.StrokeDescription(path, 0, durationMs), durationMs)
        } catch (e: Exception) {
            false
        }
    }

    private var bar: LinearLayout? = null
    private val ui = Handler(Looper.getMainLooper())

    /** A small Pause / Stop bar over the game (an accessibility overlay: needs no extra permission). */
    fun showBar(onPause: () -> Boolean, onStop: () -> Unit) {
        ui.post {
            try {
                hideBarNow()
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val d = resources.displayMetrics.density
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                row.setPadding((8 * d).toInt(), (4 * d).toInt(), (8 * d).toInt(), (4 * d).toInt())
                val bg = android.graphics.drawable.GradientDrawable()
                bg.setColor(Color.argb(210, 20, 24, 30))
                bg.cornerRadius = 22 * d
                row.background = bg
                fun btn(label: String, color: Int, click: (Button) -> Unit): Button {
                    val b = Button(this)
                    b.text = label
                    b.isAllCaps = false
                    b.textSize = 12f
                    b.setTextColor(Color.BLACK)
                    b.minHeight = 0; b.minimumHeight = 0; b.minWidth = 0; b.minimumWidth = 0
                    b.setPadding((14 * d).toInt(), (4 * d).toInt(), (14 * d).toInt(), (4 * d).toInt())
                    val g = android.graphics.drawable.GradientDrawable()
                    g.setColor(color)
                    g.cornerRadius = 16 * d
                    b.background = g
                    b.setOnClickListener { click(b) }
                    return b
                }
                val pause = btn("Pause", Color.rgb(34, 211, 238)) { b ->
                    val nowPaused = onPause()
                    b.text = if (nowPaused) "Resume" else "Pause"
                }
                val stop = btn("Stop", Color.rgb(248, 113, 113)) { onStop() }
                val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                lp.rightMargin = (8 * d).toInt()
                row.addView(pause, lp)
                row.addView(stop)
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT
                )
                params.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
                params.y = (36 * d).toInt()
                wm.addView(row, params)
                bar = row
            } catch (e: Exception) {
                AppLog.add("bar: $e")
            }
        }
    }

    fun hideBar() {
        ui.post { hideBarNow() }
    }

    private fun hideBarNow() {
        val b = bar ?: return
        bar = null
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(b)
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun tap(x: Float, y: Float): Boolean {
        release()
        val p = Path()
        p.moveTo(x, y)
        return dispatchAndWait(GestureDescription.StrokeDescription(p, 0, 60), 60)
    }

    @Synchronized
    fun back() {
        release()
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun dispatchAndWait(stroke: GestureDescription.StrokeDescription, durationMs: Long): Boolean {
        val started = System.nanoTime()
        val latch = CountDownLatch(1)
        var ok = false
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!accepted) return false
        latch.await(durationMs + 500, TimeUnit.MILLISECONDS)
        // The phone reports "done" a bit before the stroke has really ended (for a stroke that barely
        // moves it can be ~7 ms early). A follow-up stroke that starts too early is rejected, and that
        // lifts the finger: in the recorded runs about 1 in 10 gestures failed this way, always right
        // after a call that returned in less than the stroke length. So wait until it has really ended.
        val spent = (System.nanoTime() - started) / 1_000_000
        val rest = durationMs + 6 - spent
        if (rest > 0) {
            try { Thread.sleep(rest) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }
        return ok
    }
}
