package com.forestbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.os.Build
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Does the actual tapping and swiping for the bot. */
class GameAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: GameAccessibilityService? = null
    }

    // The finger that is currently held on the screen (a continuing stroke), if any.
    private var stroke: GestureDescription.StrokeDescription? = null
    private var fingerX = 0f
    private var fingerY = 0f
    private var nudge = 0.5f

    class Shot(val px: IntArray, val w: Int, val h: Int)

    /** Takes a full-size screenshot (Android 11+). Returns null if the phone refuses. */
    fun screenshot(): Shot? {
        if (Build.VERSION.SDK_INT < 30) return null
        val latch = CountDownLatch(1)
        var shot: Shot? = null
        try {
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : AccessibilityService.TakeScreenshotCallback {
                override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                    try {
                        val hb = result.hardwareBuffer
                        val bmp = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                        if (bmp != null) {
                            val soft = bmp.copy(Bitmap.Config.ARGB_8888, false)
                            val px = IntArray(soft.width * soft.height)
                            soft.getPixels(px, 0, soft.width, 0, 0, soft.width, soft.height)
                            for (i in px.indices) px[i] = px[i] and 0xFFFFFF
                            shot = Shot(px, soft.width, soft.height)
                            soft.recycle()
                        }
                        hb.close()
                    } catch (e: Exception) {
                        AppLog.add("screenshot error " + e)
                    }
                    latch.countDown()
                }

                override fun onFailure(errorCode: Int) {
                    AppLog.add("screenshot refused, code " + errorCode)
                    latch.countDown()
                }
            })
            latch.await(4, TimeUnit.SECONDS)
        } catch (e: Exception) {
            AppLog.add("screenshot error " + e)
        }
        return shot
    }

    val fingerDown: Boolean
        @Synchronized get() = stroke != null

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Keeps one finger down and slides it to (toX, y). Starts the touch at startX if none is down. */
    @Synchronized
    fun drag(toX: Float, y: Float, durationMs: Long, startX: Float): Boolean {
        try {
            val s = stroke
            val sx = if (s != null) fingerX else startX
            val sy = if (s != null) fingerY else y
            var ex = toX
            if (ex == sx && y == sy) {
                nudge = -nudge
                ex += nudge
            }
            val path = Path()
            path.moveTo(sx, sy)
            path.lineTo(ex, y)
            val desc = if (s == null) {
                GestureDescription.StrokeDescription(path, 0, durationMs, true)
            } else {
                s.continueStroke(path, 0, durationMs, true)
            }
            val ok = dispatchAndWait(desc, durationMs)
            if (ok) {
                stroke = desc
                fingerX = ex
                fingerY = y
            } else {
                stroke = null
            }
            return ok
        } catch (e: Exception) {
            stroke = null
            return false
        }
    }

    /** Lifts the finger. */
    @Synchronized
    fun release() {
        val s = stroke ?: return
        stroke = null
        try {
            val path = Path()
            path.moveTo(fingerX, fingerY)
            path.lineTo(fingerX + 0.5f, fingerY)
            dispatchAndWait(s.continueStroke(path, 0, 10, false), 10)
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun tap(x: Float, y: Float): Boolean {
        release()
        val p = Path()
        p.moveTo(x, y)
        return dispatchAndWait(GestureDescription.StrokeDescription(p, 0, 60), 60)
    }

    @Synchronized
    fun back() {
        release()
        performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun dispatchAndWait(stroke: GestureDescription.StrokeDescription, durationMs: Long): Boolean {
        val started = System.nanoTime()
        val latch = CountDownLatch(1)
        var ok = false
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                ok = true
                latch.countDown()
            }

            override fun onCancelled(gestureDescription: GestureDescription?) {
                latch.countDown()
            }
        }, null)
        if (!accepted) return false
        latch.await(durationMs + 500, TimeUnit.MILLISECONDS)
        // The phone reports "done" a bit before the stroke has really ended (for a stroke that barely
        // moves it can be ~7 ms early). A follow-up stroke that starts too early is rejected, and that
        // lifts the finger: in the recorded runs about 1 in 10 gestures failed this way, always right
        // after a call that returned in less than the stroke length. So wait until it has really ended.
        val spent = (System.nanoTime() - started) / 1_000_000
        val rest = durationMs + 6 - spent
        if (rest > 0) {
            try { Thread.sleep(rest) } catch (_: InterruptedException) { Thread.currentThread().interrupt() }
        }
        return ok
    }
}
